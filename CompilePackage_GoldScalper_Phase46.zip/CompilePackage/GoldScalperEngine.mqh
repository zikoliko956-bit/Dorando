#ifndef GOLDSCALPERENGINE_MQH_INCLUDED
#define GOLDSCALPERENGINE_MQH_INCLUDED
//+------------------------------------------------------------------+
//| Phase 4.6 — Professional XAUUSD Gold Scalper Engine               |
//| Behaviorally aligned reconstruction (v4.6 spec + MT5 architecture)|
//| Candidate-first | Core-priority scoring | Setup-specific          |
//| Closed-bar only. No license changes. No SMC hard gates.           |
//+------------------------------------------------------------------+

enum ENUM_GOLD_SETUP
  {
   GS_NONE = 0,
   GS_LIQUIDITY_SWEEP,
   GS_SUPPORT_REJECTION,
   GS_RESISTANCE_REJECTION,
   GS_BREAKOUT_RETEST,
   GS_RANGE_BREAK,
   GS_OB_RETEST,
   GS_FVG_RETEST,
   GS_STRUCTURE_CONTINUATION,
   GS_CANDLE_REVERSAL,
   GS_DISPLACEMENT_REACTION,
   GS_MICRO_FLIP,
   GS_ZONE_TO_ZONE
  };

enum ENUM_SCALP_SCORE_PRESET
  {
   SCALP_SCORE_AGGRESSIVE = 0,  // HF-oriented
   SCALP_SCORE_NORMAL     = 1,
   SCALP_SCORE_CONSERVATIVE = 2
  };

enum ENUM_ROOM_STATE
  {
   ROOM_GOOD = 0,
   ROOM_MARGINAL,
   ROOM_NONE
  };

//+------------------------------------------------------------------+
struct GoldScalpSignal
  {
   bool              valid;
   bool              pass;
   int               direction;          // +1 buy, -1 sell
   ENUM_GOLD_SETUP   setupType;
   string            setupName;
   double            score;              // TotalScore 0-100
   double            coreScore;          // 0-90
   double            secondaryScore;     // 0-10
   double            minScore;
   // Core buckets
   double            ptsSetup;
   double            ptsLocation;
   double            ptsLiquidity;
   double            ptsStructure;
   double            ptsTrigger;
   double            ptsTargetRoom;
   // Secondary buckets
   double            ptsMomentum;
   double            ptsVolume;
   double            ptsHTF;
   double            ptsSession;
   // Legacy compatibility fields (kept for main EA)
   double            ptsSR, ptsSweep, ptsCandle, ptsSmcBonus;
   double            keyLevel;
   double            suggestedSL;
   double            entryPrice;
   double            tp1, tp2, tp3, tp4;
   bool              tp3Valid, tp4Valid;
   ENUM_ROOM_STATE   roomState;
   string            decision;           // PASS / BLOCKED
   string            blockReason;
   string            fingerprint;
   datetime          barTime;
  };

//+------------------------------------------------------------------+
struct GoldCandidate
  {
   ENUM_GOLD_SETUP   setup;
   int               direction;
   double            coreScore;
   double            secondaryScore;
   double            totalScore;
   double            ptsSetup, ptsLocation, ptsLiquidity, ptsStructure, ptsTrigger, ptsTargetRoom;
   double            ptsMomentum, ptsVolume, ptsHTF, ptsSession;
   double            keyLevel;
   double            entryZoneUpper, entryZoneLower;
   double            suggestedSL;
   double            tp1, tp2, tp3, tp4;
   bool              tp3Valid, tp4Valid;
   ENUM_ROOM_STATE   roomState;
   string            blockReason;
   string            fingerprint;
   datetime          barTime;
   bool              valid;
  };

//+------------------------------------------------------------------+
class CGoldScalperEngine
  {
private:
   string            m_symbol;
   ENUM_TIMEFRAMES   m_tf;
   bool              m_ready;
   bool              m_hfMode;                 // High Frequency path
   bool              m_useSweep, m_useRejection, m_useBO, m_useRange;
   bool              m_useOB, m_useFVG, m_useStructCont, m_useCandle;
   bool              m_useDisp, m_useMicro, m_useZoneToZone;
   bool              m_sessionFilter;
   bool              m_allowCounterHtf;
   double            m_coreHQ;                 // High Quality Core floor (default 68)
   double            m_coreHF;                 // High Frequency Core floor (default 60)
   double            m_minTotalHQ;
   double            m_minTotalHF;
   int               m_cooldownBars;
   int               m_maxPerSession;
   int               m_sessionTrades;
   datetime          m_sessionDay;
   datetime          m_lastTradeBar;
   string            m_lastFingerprint;
   datetime          m_lastFingerprintBar;
   GoldScalpSignal   m_last;
   bool              m_log;
   string            m_logFile;
   int               m_logHandle;

   // stats
   int               m_gen, m_passed, m_blocked;
   int               m_candCount, m_noRoom, m_lowCore, m_lateEntry;

   //--- helpers
   double Point(void) const
     {
      double p = SymbolInfoDouble(m_symbol, SYMBOL_POINT);
      return (p > 0.0 ? p : 0.01);
     }

   double ATR(const int period = 14) const
     {
      int h = iATR(m_symbol, m_tf, period);
      if(h == INVALID_HANDLE) return Point() * 100.0;
      double b[];
      ArraySetAsSeries(b, true);
      double v = Point() * 100.0;
      if(CopyBuffer(h, 0, 1, 1, b) > 0 && b[0] > 0.0) v = b[0];
      IndicatorRelease(h);
      return v;
     }

   int ProfileSwingLookback(void) const
     {
      int sec = (int)PeriodSeconds(m_tf);
      if(sec <= 60)   return 25;
      if(sec <= 180)  return 30;
      if(sec <= 300)  return 35;
      if(sec <= 900)  return 40;
      if(sec <= 1800) return 50;
      return 60;
     }

   int ProfileMicroLookback(void) const
     {
      int sec = (int)PeriodSeconds(m_tf);
      if(sec <= 60)   return 6;
      if(sec <= 180)  return 8;
      if(sec <= 300)  return 10;
      if(sec <= 900)  return 12;
      return 15;
     }

   double ProfileMaxSlAtr(void) const
     {
      int sec = (int)PeriodSeconds(m_tf);
      if(sec <= 60)   return 0.90;
      if(sec <= 300)  return 1.10;
      if(sec <= 900)  return 1.20;
      return 1.40;
     }

   bool InPrioritySession(void) const
     {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      // Soft preference band (server time approximation)
      return (dt.hour >= 7 && dt.hour <= 21);
     }

   //--- simple relative volume proxy (soft)
   double RelVolume(void) const
     {
      long v1 = iVolume(m_symbol, m_tf, 1);
      long sum = 0;
      int n = 0;
      for(int i = 2; i <= 21; i++)
        {
         long v = iVolume(m_symbol, m_tf, i);
         if(v > 0) { sum += v; n++; }
        }
      if(n < 5 || sum <= 0) return 1.0;
      double avg = (double)sum / n;
      if(avg <= 0.0) return 1.0;
      return (double)v1 / avg;
     }

   //--- candle quality relative to direction (soft, never hard-block alone)
   double CandleQuality(const int dir) const
     {
      double o = iOpen(m_symbol, m_tf, 1);
      double h = iHigh(m_symbol, m_tf, 1);
      double l = iLow(m_symbol, m_tf, 1);
      double c = iClose(m_symbol, m_tf, 1);
      if(o <= 0.0 || h <= l) return 0.0;
      double range = h - l;
      if(range <= 0.0) return 0.0;
      double body = MathAbs(c - o);
      double upper = h - MathMax(o, c);
      double lower = MathMin(o, c) - l;
      double pts = 0.0;
      if(dir > 0)
        {
         if(c > o && body >= 0.40 * range) pts += 6.0;
         if(lower >= 0.35 * range && body <= 0.40 * range) pts += 5.0; // pin
         if(c > o && lower > upper) pts += 3.0;
        }
      else if(dir < 0)
        {
         if(c < o && body >= 0.40 * range) pts += 6.0;
         if(upper >= 0.35 * range && body <= 0.40 * range) pts += 5.0;
         if(c < o && upper > lower) pts += 3.0;
        }
      return MathMin(10.0, pts);
     }

   double MomentumQuality(const int dir) const
     {
      double atr = ATR();
      double c1 = iClose(m_symbol, m_tf, 1);
      double c2 = iClose(m_symbol, m_tf, 2);
      double c3 = iClose(m_symbol, m_tf, 3);
      double pts = 0.0;
      if(atr > 0.0 && MathAbs(c1 - c2) >= 0.25 * atr) pts += 2.0;
      if(dir > 0 && c1 > c2 && c2 >= c3) pts += 2.0;
      if(dir < 0 && c1 < c2 && c2 <= c3) pts += 2.0;
      return MathMin(4.0, pts);
     }

   //--- recent swing high/low (closed bars)
   void RecentSwing(const int look, double &outHigh, double &outLow) const
     {
      outHigh = iHigh(m_symbol, m_tf, 2);
      outLow  = iLow(m_symbol, m_tf, 2);
      for(int i = 3; i <= look; i++)
        {
         double h = iHigh(m_symbol, m_tf, i);
         double l = iLow(m_symbol, m_tf, i);
         if(h > outHigh) outHigh = h;
         if(l < outLow)  outLow  = l;
        }
     }

   //--- equal high / equal low detection (simple cluster)
   bool FindEqualHigh(double &level, double &quality) const
     {
      level = 0.0; quality = 0.0;
      double atr = ATR();
      if(atr <= 0.0) return false;
      int look = ProfileSwingLookback();
      double hi = iHigh(m_symbol, m_tf, 2);
      int touches = 1;
      for(int i = 3; i <= look; i++)
        {
         double h = iHigh(m_symbol, m_tf, i);
         if(h > hi + 0.05 * atr) { hi = h; touches = 1; }
         else if(MathAbs(h - hi) <= 0.18 * atr) touches++;
        }
      if(touches >= 2)
        {
         level = hi;
         quality = MathMin(15.0, 6.0 + touches * 3.0);
         return true;
        }
      return false;
     }

   bool FindEqualLow(double &level, double &quality) const
     {
      level = 0.0; quality = 0.0;
      double atr = ATR();
      if(atr <= 0.0) return false;
      int look = ProfileSwingLookback();
      double lo = iLow(m_symbol, m_tf, 2);
      int touches = 1;
      for(int i = 3; i <= look; i++)
        {
         double l = iLow(m_symbol, m_tf, i);
         if(l < lo - 0.05 * atr) { lo = l; touches = 1; }
         else if(MathAbs(l - lo) <= 0.18 * atr) touches++;
        }
      if(touches >= 2)
        {
         level = lo;
         quality = MathMin(15.0, 6.0 + touches * 3.0);
         return true;
        }
      return false;
     }

   //--- simple zone (support or resistance) from recent swings + touches
   bool FindZone(const int dir, double &center, double &upper, double &lower, double &strength) const
     {
      center = 0.0; upper = 0.0; lower = 0.0; strength = 0.0;
      double atr = ATR();
      if(atr <= 0.0) return false;
      int look = ProfileSwingLookback();
      if(dir < 0) // resistance
        {
         double hi = iHigh(m_symbol, m_tf, 2);
         int touches = 0;
         for(int i = 2; i <= look; i++)
           {
            double h = iHigh(m_symbol, m_tf, i);
            if(h > hi) hi = h;
           }
         for(int i = 2; i <= look; i++)
            if(MathAbs(iHigh(m_symbol, m_tf, i) - hi) <= 0.20 * atr) touches++;
         center = hi;
         upper  = hi + 0.12 * atr;
         lower  = hi - 0.18 * atr;
         strength = MathMin(20.0, 8.0 + touches * 3.5);
         return (touches >= 1);
        }
      else // support
        {
         double lo = iLow(m_symbol, m_tf, 2);
         int touches = 0;
         for(int i = 2; i <= look; i++)
           {
            double l = iLow(m_symbol, m_tf, i);
            if(l < lo) lo = l;
           }
         for(int i = 2; i <= look; i++)
            if(MathAbs(iLow(m_symbol, m_tf, i) - lo) <= 0.20 * atr) touches++;
         center = lo;
         upper  = lo + 0.18 * atr;
         lower  = lo - 0.12 * atr;
         strength = MathMin(20.0, 8.0 + touches * 3.5);
         return (touches >= 1);
        }
     }

   //--- micro structure direction (simple HH/HL vs LH/LL)
   int MicroDirection(void) const
     {
      int lb = ProfileMicroLookback();
      double c1 = iClose(m_symbol, m_tf, 1);
      double h1 = iHigh(m_symbol, m_tf, 1);
      double l1 = iLow(m_symbol, m_tf, 1);
      double hh = iHigh(m_symbol, m_tf, 2);
      double ll = iLow(m_symbol, m_tf, 2);
      for(int i = 3; i <= lb; i++)
        {
         if(iHigh(m_symbol, m_tf, i) > hh) hh = iHigh(m_symbol, m_tf, i);
         if(iLow(m_symbol, m_tf, i)  < ll) ll = iLow(m_symbol, m_tf, i);
        }
      // very light micro BOS proxy
      if(c1 > hh && h1 > hh) return +1;
      if(c1 < ll && l1 < ll) return -1;
      // pullback continuation bias
      double c3 = iClose(m_symbol, m_tf, 3);
      double c5 = iClose(m_symbol, m_tf, MathMin(5, lb));
      if(c5 < c3 && c3 < c1) return +1;
      if(c5 > c3 && c3 > c1) return -1;
      return 0;
     }

   //--- displacement detection (strong body relative to ATR)
   bool HasDisplacement(const int dir, double &quality) const
     {
      quality = 0.0;
      double atr = ATR();
      if(atr <= 0.0) return false;
      double o = iOpen(m_symbol, m_tf, 1);
      double c = iClose(m_symbol, m_tf, 1);
      double body = MathAbs(c - o);
      if(body < 0.55 * atr) return false;
      if(dir > 0 && c > o) { quality = MathMin(12.0, 6.0 + (body / atr) * 4.0); return true; }
      if(dir < 0 && c < o) { quality = MathMin(12.0, 6.0 + (body / atr) * 4.0); return true; }
      return false;
     }

   //+------------------------------------------------------------------+
   //| SETUP DETECTORS (independent candidates)                         |
   //+------------------------------------------------------------------+
   bool DetectLiquiditySweep(GoldCandidate &cand)
     {
      cand.setup = GS_LIQUIDITY_SWEEP;
      cand.valid = false;
      double atr = ATR();
      if(atr <= 0.0) return false;

      double prevHigh, prevLow;
      RecentSwing(MathMin(18, ProfileSwingLookback()), prevHigh, prevLow);

      double h1 = iHigh(m_symbol, m_tf, 1);
      double l1 = iLow(m_symbol, m_tf, 1);
      double c1 = iClose(m_symbol, m_tf, 1);
      double range = h1 - l1;
      if(range <= 0.0) return false;

      // Sell-side liquidity sweep (buy setup)
      if(l1 < prevLow - 0.05 * atr && c1 > prevLow && c1 > l1 + 0.28 * range)
        {
         cand.direction = +1;
         cand.keyLevel  = prevLow;
         cand.entryZoneLower = prevLow - 0.15 * atr;
         cand.entryZoneUpper = prevLow + 0.35 * atr;
         cand.ptsLiquidity = 13.0;
         cand.ptsSetup     = 20.0;
         // boost if equal low
         double eqLvl, eqQ;
         if(FindEqualLow(eqLvl, eqQ) && MathAbs(eqLvl - prevLow) <= 0.25 * atr)
            cand.ptsLiquidity = MathMin(15.0, 13.0 + eqQ * 0.3);
         cand.valid = true;
         return true;
        }
      // Buy-side liquidity sweep (sell setup)
      if(h1 > prevHigh + 0.05 * atr && c1 < prevHigh && c1 < h1 - 0.28 * range)
        {
         cand.direction = -1;
         cand.keyLevel  = prevHigh;
         cand.entryZoneLower = prevHigh - 0.35 * atr;
         cand.entryZoneUpper = prevHigh + 0.15 * atr;
         cand.ptsLiquidity = 13.0;
         cand.ptsSetup     = 20.0;
         double eqLvl, eqQ;
         if(FindEqualHigh(eqLvl, eqQ) && MathAbs(eqLvl - prevHigh) <= 0.25 * atr)
            cand.ptsLiquidity = MathMin(15.0, 13.0 + eqQ * 0.3);
         cand.valid = true;
         return true;
        }
      return false;
     }

   bool DetectSupportRejection(GoldCandidate &cand)
     {
      cand.setup = GS_SUPPORT_REJECTION;
      cand.valid = false;
      double center, upper, lower, strength;
      if(!FindZone(+1, center, upper, lower, strength)) return false;
      double c1 = iClose(m_symbol, m_tf, 1);
      double l1 = iLow(m_symbol, m_tf, 1);
      double atr = ATR();
      // price interacted with support and closed back above
      if(l1 <= upper && c1 >= center && c1 > l1)
        {
         cand.direction = +1;
         cand.keyLevel  = center;
         cand.entryZoneLower = lower;
         cand.entryZoneUpper = upper;
         cand.ptsLocation = strength;
         cand.ptsSetup    = 16.0 + MathMin(6.0, strength * 0.2);
         cand.ptsTrigger  = CandleQuality(+1);
         cand.valid = true;
         return true;
        }
      return false;
     }

   bool DetectResistanceRejection(GoldCandidate &cand)
     {
      cand.setup = GS_RESISTANCE_REJECTION;
      cand.valid = false;
      double center, upper, lower, strength;
      if(!FindZone(-1, center, upper, lower, strength)) return false;
      double c1 = iClose(m_symbol, m_tf, 1);
      double h1 = iHigh(m_symbol, m_tf, 1);
      if(h1 >= lower && c1 <= center && c1 < h1)
        {
         cand.direction = -1;
         cand.keyLevel  = center;
         cand.entryZoneLower = lower;
         cand.entryZoneUpper = upper;
         cand.ptsLocation = strength;
         cand.ptsSetup    = 16.0 + MathMin(6.0, strength * 0.2);
         cand.ptsTrigger  = CandleQuality(-1);
         cand.valid = true;
         return true;
        }
      return false;
     }

   bool DetectBreakoutRetest(GoldCandidate &cand)
     {
      cand.setup = GS_BREAKOUT_RETEST;
      cand.valid = false;
      double atr = ATR();
      int look = ProfileSwingLookback();
      double hi = iHigh(m_symbol, m_tf, 4);
      double lo = iLow(m_symbol, m_tf, 4);
      for(int i = 5; i <= look; i++)
        {
         if(iHigh(m_symbol, m_tf, i) > hi) hi = iHigh(m_symbol, m_tf, i);
         if(iLow(m_symbol, m_tf, i)  < lo) lo = iLow(m_symbol, m_tf, i);
        }
      double c3 = iClose(m_symbol, m_tf, 3);
      double c2 = iClose(m_symbol, m_tf, 2);
      double c1 = iClose(m_symbol, m_tf, 1);
      double l1 = iLow(m_symbol, m_tf, 1);
      double h1 = iHigh(m_symbol, m_tf, 1);

      // bullish break + retest
      if(c3 > hi && c2 >= hi - 0.25 * atr && l1 <= hi + 0.20 * atr && c1 > hi)
        {
         cand.direction = +1;
         cand.keyLevel  = hi;
         cand.entryZoneLower = hi - 0.15 * atr;
         cand.entryZoneUpper = hi + 0.30 * atr;
         cand.ptsSetup    = 18.0;
         cand.ptsLocation = 12.0;
         cand.ptsTrigger  = CandleQuality(+1) * 0.8;
         cand.valid = true;
         return true;
        }
      // bearish break + retest
      if(c3 < lo && c2 <= lo + 0.25 * atr && h1 >= lo - 0.20 * atr && c1 < lo)
        {
         cand.direction = -1;
         cand.keyLevel  = lo;
         cand.entryZoneLower = lo - 0.30 * atr;
         cand.entryZoneUpper = lo + 0.15 * atr;
         cand.ptsSetup    = 18.0;
         cand.ptsLocation = 12.0;
         cand.ptsTrigger  = CandleQuality(-1) * 0.8;
         cand.valid = true;
         return true;
        }
      return false;
     }

   bool DetectRangeBreak(GoldCandidate &cand)
     {
      cand.setup = GS_RANGE_BREAK;
      cand.valid = false;
      double atr = ATR();
      int look = MathMin(30, ProfileSwingLookback());
      double hi = iHigh(m_symbol, m_tf, 2);
      double lo = iLow(m_symbol, m_tf, 2);
      for(int i = 3; i <= look; i++)
        {
         if(iHigh(m_symbol, m_tf, i) > hi) hi = iHigh(m_symbol, m_tf, i);
         if(iLow(m_symbol, m_tf, i)  < lo) lo = iLow(m_symbol, m_tf, i);
        }
      double range = hi - lo;
      if(range < 1.2 * atr) return false; // too tight
      double c1 = iClose(m_symbol, m_tf, 1);
      if(c1 > hi + 0.05 * atr)
        {
         cand.direction = +1;
         cand.keyLevel  = hi;
         cand.ptsSetup  = 15.0;
         cand.ptsLocation = 10.0;
         cand.ptsTrigger  = CandleQuality(+1);
         cand.valid = true;
         return true;
        }
      if(c1 < lo - 0.05 * atr)
        {
         cand.direction = -1;
         cand.keyLevel  = lo;
         cand.ptsSetup  = 15.0;
         cand.ptsLocation = 10.0;
         cand.ptsTrigger  = CandleQuality(-1);
         cand.valid = true;
         return true;
        }
      return false;
     }

   bool DetectOBRetest(GoldCandidate &cand)
     {
      // Lightweight proxy: treat recent strong opposite candle as OB zone
      // (full SmartMoneyEngine integration can be added later via pointer injection)
      cand.setup = GS_OB_RETEST;
      cand.valid = false;
      double atr = ATR();
      if(atr <= 0.0) return false;
      // look for a strong opposite candle 3-8 bars ago and price returning
      for(int i = 3; i <= 8; i++)
        {
         double o = iOpen(m_symbol, m_tf, i);
         double c = iClose(m_symbol, m_tf, i);
         double h = iHigh(m_symbol, m_tf, i);
         double l = iLow(m_symbol, m_tf, i);
         double body = MathAbs(c - o);
         if(body < 0.45 * atr) continue;
         double c1 = iClose(m_symbol, m_tf, 1);
         // bullish OB (bearish candle) — price returns into it
         if(c < o && c1 >= l && c1 <= h && iClose(m_symbol, m_tf, 1) > iOpen(m_symbol, m_tf, 1))
           {
            cand.direction = +1;
            cand.keyLevel  = (h + l) * 0.5;
            cand.entryZoneLower = l;
            cand.entryZoneUpper = h;
            cand.ptsSetup    = 17.0;
            cand.ptsLocation = 14.0;
            cand.ptsTrigger  = CandleQuality(+1);
            cand.valid = true;
            return true;
           }
         // bearish OB
         if(c > o && c1 >= l && c1 <= h && iClose(m_symbol, m_tf, 1) < iOpen(m_symbol, m_tf, 1))
           {
            cand.direction = -1;
            cand.keyLevel  = (h + l) * 0.5;
            cand.entryZoneLower = l;
            cand.entryZoneUpper = h;
            cand.ptsSetup    = 17.0;
            cand.ptsLocation = 14.0;
            cand.ptsTrigger  = CandleQuality(-1);
            cand.valid = true;
            return true;
           }
        }
      return false;
     }

   bool DetectFVGRetest(GoldCandidate &cand)
     {
      cand.setup = GS_FVG_RETEST;
      cand.valid = false;
      double atr = ATR();
      // classic 3-candle FVG on bars 2-4, price returning on bar 1
      for(int i = 2; i <= 6; i++)
        {
         double h3 = iHigh(m_symbol, m_tf, i + 2);
         double l1 = iLow(m_symbol, m_tf, i);
         double l3 = iLow(m_symbol, m_tf, i + 2);
         double h1 = iHigh(m_symbol, m_tf, i);
         // bullish FVG
         if(l1 > h3)
           {
            double gapTop = l1;
            double gapBot = h3;
            double c1 = iClose(m_symbol, m_tf, 1);
            double low1 = iLow(m_symbol, m_tf, 1);
            if(low1 <= gapTop && c1 >= gapBot && c1 > iOpen(m_symbol, m_tf, 1))
              {
               cand.direction = +1;
               cand.keyLevel  = (gapTop + gapBot) * 0.5;
               cand.entryZoneLower = gapBot;
               cand.entryZoneUpper = gapTop;
               cand.ptsSetup    = 16.0;
               cand.ptsLocation = 12.0;
               cand.ptsTrigger  = CandleQuality(+1);
               cand.valid = true;
               return true;
              }
           }
         // bearish FVG
         if(h1 < l3)
           {
            double gapTop = l3;
            double gapBot = h1;
            double c1 = iClose(m_symbol, m_tf, 1);
            double high1 = iHigh(m_symbol, m_tf, 1);
            if(high1 >= gapBot && c1 <= gapTop && c1 < iOpen(m_symbol, m_tf, 1))
              {
               cand.direction = -1;
               cand.keyLevel  = (gapTop + gapBot) * 0.5;
               cand.entryZoneLower = gapBot;
               cand.entryZoneUpper = gapTop;
               cand.ptsSetup    = 16.0;
               cand.ptsLocation = 12.0;
               cand.ptsTrigger  = CandleQuality(-1);
               cand.valid = true;
               return true;
              }
           }
        }
      return false;
     }

   bool DetectStructureContinuation(GoldCandidate &cand)
     {
      cand.setup = GS_STRUCTURE_CONTINUATION;
      cand.valid = false;
      int micro = MicroDirection();
      if(micro == 0) return false;
      double atr = ATR();
      double c1 = iClose(m_symbol, m_tf, 1);
      double c3 = iClose(m_symbol, m_tf, 3);
      // simple continuation: micro bias + recent higher-low / lower-high pullback
      if(micro > 0 && c1 > c3)
        {
         double pullLow = iLow(m_symbol, m_tf, 2);
         if(c1 > pullLow)
           {
            cand.direction = +1;
            cand.keyLevel  = pullLow;
            cand.ptsSetup  = 15.0;
            cand.ptsStructure = 10.0;
            cand.ptsTrigger = CandleQuality(+1);
            cand.valid = true;
            return true;
           }
        }
      if(micro < 0 && c1 < c3)
        {
         double pullHigh = iHigh(m_symbol, m_tf, 2);
         if(c1 < pullHigh)
           {
            cand.direction = -1;
            cand.keyLevel  = pullHigh;
            cand.ptsSetup  = 15.0;
            cand.ptsStructure = 10.0;
            cand.ptsTrigger = CandleQuality(-1);
            cand.valid = true;
            return true;
           }
        }
      return false;
     }

   bool DetectCandleReversal(GoldCandidate &cand)
     {
      cand.setup = GS_CANDLE_REVERSAL;
      cand.valid = false;
      // requires strong location
      double center, upper, lower, strength;
      // try both sides
      bool nearSup = FindZone(+1, center, upper, lower, strength);
      if(nearSup && strength >= 12.0)
        {
         double cq = CandleQuality(+1);
         if(cq >= 6.0)
           {
            double c1 = iClose(m_symbol, m_tf, 1);
            if(c1 >= lower && c1 <= upper + ATR() * 0.3)
              {
               cand.direction = +1;
               cand.keyLevel  = center;
               cand.ptsSetup  = 12.0;
               cand.ptsLocation = strength;
               cand.ptsTrigger = cq;
               cand.valid = true;
               return true;
              }
           }
        }
      nearSup = FindZone(-1, center, upper, lower, strength);
      if(nearSup && strength >= 12.0)
        {
         double cq = CandleQuality(-1);
         if(cq >= 6.0)
           {
            double c1 = iClose(m_symbol, m_tf, 1);
            if(c1 <= upper && c1 >= lower - ATR() * 0.3)
              {
               cand.direction = -1;
               cand.keyLevel  = center;
               cand.ptsSetup  = 12.0;
               cand.ptsLocation = strength;
               cand.ptsTrigger = cq;
               cand.valid = true;
               return true;
              }
           }
        }
      return false;
     }

   bool DetectDisplacementReaction(GoldCandidate &cand)
     {
      cand.setup = GS_DISPLACEMENT_REACTION;
      cand.valid = false;
      double q;
      // displacement on bar 2, reaction on bar 1
      double atr = ATR();
      double o2 = iOpen(m_symbol, m_tf, 2);
      double c2 = iClose(m_symbol, m_tf, 2);
      double body2 = MathAbs(c2 - o2);
      if(body2 < 0.60 * atr) return false;
      double c1 = iClose(m_symbol, m_tf, 1);
      if(c2 > o2 && c1 < c2 && c1 > o2) // bullish displacement then mild reaction still above open
        {
         cand.direction = +1;
         cand.keyLevel  = o2;
         cand.ptsSetup  = 16.0;
         cand.ptsTrigger = 8.0;
         cand.ptsStructure = 6.0;
         cand.valid = true;
         return true;
        }
      if(c2 < o2 && c1 > c2 && c1 < o2)
        {
         cand.direction = -1;
         cand.keyLevel  = o2;
         cand.ptsSetup  = 16.0;
         cand.ptsTrigger = 8.0;
         cand.ptsStructure = 6.0;
         cand.valid = true;
         return true;
        }
      return false;
     }

   bool DetectMicroFlip(GoldCandidate &cand)
     {
      cand.setup = GS_MICRO_FLIP;
      cand.valid = false;
      int lb = ProfileMicroLookback();
      double c1 = iClose(m_symbol, m_tf, 1);
      double hh = iHigh(m_symbol, m_tf, 2);
      double ll = iLow(m_symbol, m_tf, 2);
      for(int i = 3; i <= lb; i++)
        {
         if(iHigh(m_symbol, m_tf, i) > hh) hh = iHigh(m_symbol, m_tf, i);
         if(iLow(m_symbol, m_tf, i)  < ll) ll = iLow(m_symbol, m_tf, i);
        }
      // bullish flip: close above recent micro high after having been below
      if(c1 > hh && iClose(m_symbol, m_tf, 3) < hh)
        {
         cand.direction = +1;
         cand.keyLevel  = hh;
         cand.ptsSetup  = 14.0;
         cand.ptsStructure = 9.0;
         cand.ptsTrigger = CandleQuality(+1);
         cand.valid = true;
         return true;
        }
      if(c1 < ll && iClose(m_symbol, m_tf, 3) > ll)
        {
         cand.direction = -1;
         cand.keyLevel  = ll;
         cand.ptsSetup  = 14.0;
         cand.ptsStructure = 9.0;
         cand.ptsTrigger = CandleQuality(-1);
         cand.valid = true;
         return true;
        }
      return false;
     }

   bool DetectZoneToZone(GoldCandidate &cand)
     {
      cand.setup = GS_ZONE_TO_ZONE;
      cand.valid = false;
      double sCenter, sUpper, sLower, sStr;
      double rCenter, rUpper, rLower, rStr;
      bool hasS = FindZone(+1, sCenter, sUpper, sLower, sStr);
      bool hasR = FindZone(-1, rCenter, rUpper, rLower, rStr);
      if(!hasS || !hasR) return false;
      double atr = ATR();
      double c1 = iClose(m_symbol, m_tf, 1);
      // at support with clear room to resistance
      if(c1 <= sUpper + 0.15 * atr && c1 >= sLower - 0.10 * atr && (rCenter - c1) >= 0.7 * atr)
        {
         cand.direction = +1;
         cand.keyLevel  = sCenter;
         cand.ptsSetup  = 15.0;
         cand.ptsLocation = sStr;
         cand.ptsTargetRoom = MathMin(8.0, ((rCenter - c1) / atr) * 3.0);
         cand.ptsTrigger = CandleQuality(+1);
         cand.valid = true;
         return true;
        }
      if(c1 >= rLower - 0.15 * atr && c1 <= rUpper + 0.10 * atr && (c1 - sCenter) >= 0.7 * atr)
        {
         cand.direction = -1;
         cand.keyLevel  = rCenter;
         cand.ptsSetup  = 15.0;
         cand.ptsLocation = rStr;
         cand.ptsTargetRoom = MathMin(8.0, ((c1 - sCenter) / atr) * 3.0);
         cand.ptsTrigger = CandleQuality(-1);
         cand.valid = true;
         return true;
        }
      return false;
     }

   //+------------------------------------------------------------------+
   //| Scoring, room, SL, TP                                            |
   //+------------------------------------------------------------------+
   void FillSecondary(GoldCandidate &cand)
     {
      cand.ptsMomentum = MomentumQuality(cand.direction);
      double rv = RelVolume();
      cand.ptsVolume = 0.0;
      if(rv >= 1.15) cand.ptsVolume = 2.0;
      if(rv >= 1.40) cand.ptsVolume = 3.0;
      // HTF soft (simple higher-TF close bias using period*4 approximation)
      cand.ptsHTF = 1.0; // neutral default
      if(m_allowCounterHtf) cand.ptsHTF = 1.0;
      cand.ptsSession = (InPrioritySession() ? 1.0 : 0.3);
      if(!m_sessionFilter) cand.ptsSession = 1.0;

      cand.secondaryScore = cand.ptsMomentum + cand.ptsVolume + cand.ptsHTF + cand.ptsSession;
      if(cand.secondaryScore > 10.0) cand.secondaryScore = 10.0;
     }

   void FillCoreAndTotal(GoldCandidate &cand)
     {
      // ensure buckets are capped
      cand.ptsSetup      = MathMin(25.0, MathMax(0.0, cand.ptsSetup));
      cand.ptsLocation   = MathMin(20.0, MathMax(0.0, cand.ptsLocation));
      cand.ptsLiquidity  = MathMin(15.0, MathMax(0.0, cand.ptsLiquidity));
      cand.ptsStructure  = MathMin(12.0, MathMax(0.0, cand.ptsStructure));
      cand.ptsTrigger    = MathMin(10.0, MathMax(0.0, cand.ptsTrigger));
      cand.ptsTargetRoom = MathMin(8.0,  MathMax(0.0, cand.ptsTargetRoom));

      // default missing core pieces from available context
      if(cand.ptsLocation <= 0.0 && cand.keyLevel > 0.0) cand.ptsLocation = 8.0;
      if(cand.ptsStructure <= 0.0)
        {
         int md = MicroDirection();
         if(md == cand.direction) cand.ptsStructure = 7.0;
         else if(md == 0) cand.ptsStructure = 4.0;
         else cand.ptsStructure = 2.0;
        }
      if(cand.ptsTrigger <= 0.0) cand.ptsTrigger = CandleQuality(cand.direction) * 0.7;

      cand.coreScore = cand.ptsSetup + cand.ptsLocation + cand.ptsLiquidity
                       + cand.ptsStructure + cand.ptsTrigger + cand.ptsTargetRoom;
      if(cand.coreScore > 90.0) cand.coreScore = 90.0;

      FillSecondary(cand);
      cand.totalScore = cand.coreScore + cand.secondaryScore;
      if(cand.totalScore > 100.0) cand.totalScore = 100.0;
     }

   void EvaluateTargetRoom(GoldCandidate &cand)
     {
      double atr = ATR();
      if(atr <= 0.0) { cand.roomState = ROOM_NONE; cand.ptsTargetRoom = 0.0; return; }
      double entry = iClose(m_symbol, m_tf, 1);
      double swingH, swingL;
      RecentSwing(ProfileSwingLookback(), swingH, swingL);

      double room = 0.0;
      if(cand.direction > 0)
         room = swingH - entry;
      else
         room = entry - swingL;

      // also consider opposite zone
      double oc, ou, ol, os;
      if(cand.direction > 0 && FindZone(-1, oc, ou, ol, os))
         room = MathMin(room, oc - entry);
      if(cand.direction < 0 && FindZone(+1, oc, ou, ol, os))
         room = MathMin(room, entry - oc);

      if(room >= 0.85 * atr)
        {
         cand.roomState = ROOM_GOOD;
         cand.ptsTargetRoom = MathMin(8.0, 4.0 + (room / atr) * 2.5);
        }
      else if(room >= 0.45 * atr)
        {
         cand.roomState = ROOM_MARGINAL;
         cand.ptsTargetRoom = MathMin(5.0, 2.0 + (room / atr) * 2.0);
        }
      else
        {
         cand.roomState = ROOM_NONE;
         cand.ptsTargetRoom = 0.0;
        }
     }

   void ComputeSL(GoldCandidate &cand)
     {
      double atr = ATR();
      double c = iClose(m_symbol, m_tf, 1);
      double sl = 0.0;
      // structure-first
      if(cand.direction > 0)
        {
         sl = iLow(m_symbol, m_tf, 1);
         for(int i = 2; i <= 6; i++)
            if(iLow(m_symbol, m_tf, i) < sl) sl = iLow(m_symbol, m_tf, i);
         if(cand.keyLevel > 0.0 && cand.keyLevel < sl) sl = cand.keyLevel;
         if(cand.entryZoneLower > 0.0 && cand.entryZoneLower < sl) sl = cand.entryZoneLower;
         sl -= 0.12 * atr;
        }
      else
        {
         sl = iHigh(m_symbol, m_tf, 1);
         for(int i = 2; i <= 6; i++)
            if(iHigh(m_symbol, m_tf, i) > sl) sl = iHigh(m_symbol, m_tf, i);
         if(cand.keyLevel > 0.0 && cand.keyLevel > sl) sl = cand.keyLevel;
         if(cand.entryZoneUpper > 0.0 && cand.entryZoneUpper > sl) sl = cand.entryZoneUpper;
         sl += 0.12 * atr;
        }
      // ATR cap
      double maxDist = ProfileMaxSlAtr() * atr;
      if(cand.direction > 0 && (c - sl) > maxDist) sl = c - maxDist;
      if(cand.direction < 0 && (sl - c) > maxDist) sl = c + maxDist;
      // absolute soft cap
      double maxPts = 2800.0 * Point();
      if(cand.direction > 0 && (c - sl) > maxPts) sl = c - maxPts;
      if(cand.direction < 0 && (sl - c) > maxPts) sl = c + maxPts;
      cand.suggestedSL = sl;
     }

   void ComputeTPs(GoldCandidate &cand)
     {
      double atr = ATR();
      double entry = iClose(m_symbol, m_tf, 1);
      double risk = MathAbs(entry - cand.suggestedSL);
      if(risk <= 0.0) risk = 0.7 * atr;

      double swingH, swingL;
      RecentSwing(ProfileSwingLookback(), swingH, swingL);

      if(cand.direction > 0)
        {
         // TP1 = nearest practical (micro / 0.7-0.9R)
         cand.tp1 = entry + MathMax(0.55 * atr, risk * 0.75);
         // TP2 = next structure / 1.4-1.8R
         cand.tp2 = entry + MathMax(1.0 * atr, risk * 1.45);
         if(swingH > cand.tp2) cand.tp2 = MathMin(cand.tp2 + 0.3 * atr, swingH);
         // TP3 / TP4 optional
         cand.tp3 = entry + MathMax(1.7 * atr, risk * 2.3);
         cand.tp4 = entry + MathMax(2.6 * atr, risk * 3.5);
         cand.tp3Valid = (swingH - entry) >= 1.5 * atr;
         cand.tp4Valid = (swingH - entry) >= 2.4 * atr;
         if(!cand.tp3Valid) cand.tp3 = 0.0;
         if(!cand.tp4Valid) cand.tp4 = 0.0;
        }
      else
        {
         cand.tp1 = entry - MathMax(0.55 * atr, risk * 0.75);
         cand.tp2 = entry - MathMax(1.0 * atr, risk * 1.45);
         if(swingL < cand.tp2) cand.tp2 = MathMax(cand.tp2 - 0.3 * atr, swingL);
         cand.tp3 = entry - MathMax(1.7 * atr, risk * 2.3);
         cand.tp4 = entry - MathMax(2.6 * atr, risk * 3.5);
         cand.tp3Valid = (entry - swingL) >= 1.5 * atr;
         cand.tp4Valid = (entry - swingL) >= 2.4 * atr;
         if(!cand.tp3Valid) cand.tp3 = 0.0;
         if(!cand.tp4Valid) cand.tp4 = 0.0;
        }
     }

   bool ApplyAntiChase(GoldCandidate &cand)
     {
      double atr = ATR();
      if(atr <= 0.0) return true;
      double c = iClose(m_symbol, m_tf, 1);
      // for reversals: if already extended far from key level → late
      if(cand.setup == GS_LIQUIDITY_SWEEP || cand.setup == GS_SUPPORT_REJECTION ||
         cand.setup == GS_RESISTANCE_REJECTION || cand.setup == GS_CANDLE_REVERSAL)
        {
         if(cand.keyLevel > 0.0)
           {
            double dist = MathAbs(c - cand.keyLevel);
            if(dist > 1.15 * atr) return false; // late
           }
        }
      // breakout / continuation allowed more extension
      return true;
     }

   double SetupSpecificTotalFloor(const ENUM_GOLD_SETUP s) const
     {
      // practical floors — not ultra-conservative
      switch(s)
        {
         case GS_LIQUIDITY_SWEEP:        return m_hfMode ? 54.0 : 58.0;
         case GS_SUPPORT_REJECTION:
         case GS_RESISTANCE_REJECTION:   return m_hfMode ? 56.0 : 60.0;
         case GS_BREAKOUT_RETEST:        return m_hfMode ? 58.0 : 62.0;
         case GS_RANGE_BREAK:            return m_hfMode ? 57.0 : 61.0;
         case GS_OB_RETEST:
         case GS_FVG_RETEST:             return m_hfMode ? 55.0 : 59.0;
         case GS_STRUCTURE_CONTINUATION: return m_hfMode ? 57.0 : 61.0;
         case GS_CANDLE_REVERSAL:        return m_hfMode ? 60.0 : 65.0;
         case GS_DISPLACEMENT_REACTION:  return m_hfMode ? 55.0 : 59.0;
         case GS_MICRO_FLIP:             return m_hfMode ? 58.0 : 63.0;
         case GS_ZONE_TO_ZONE:           return m_hfMode ? 55.0 : 59.0;
         default:                        return m_hfMode ? 58.0 : 62.0;
        }
     }

   int SetupPriority(const ENUM_GOLD_SETUP s) const
     {
      // tie-breaker only
      switch(s)
        {
         case GS_LIQUIDITY_SWEEP: return 12;
         case GS_ZONE_TO_ZONE:    return 11;
         case GS_SUPPORT_REJECTION:
         case GS_RESISTANCE_REJECTION: return 10;
         case GS_BREAKOUT_RETEST: return 9;
         case GS_OB_RETEST:       return 8;
         case GS_DISPLACEMENT_REACTION: return 7;
         case GS_STRUCTURE_CONTINUATION: return 6;
         case GS_FVG_RETEST:      return 5;
         case GS_RANGE_BREAK:     return 4;
         case GS_MICRO_FLIP:      return 3;
         case GS_CANDLE_REVERSAL: return 2;
         default: return 0;
        }
     }

   string SetupName(const ENUM_GOLD_SETUP s) const
     {
      switch(s)
        {
         case GS_LIQUIDITY_SWEEP: return "LIQUIDITY_SWEEP";
         case GS_SUPPORT_REJECTION: return "SUPPORT_REJECTION";
         case GS_RESISTANCE_REJECTION: return "RESISTANCE_REJECTION";
         case GS_BREAKOUT_RETEST: return "BREAKOUT_RETEST";
         case GS_RANGE_BREAK: return "RANGE_BREAK";
         case GS_OB_RETEST: return "OB_RETEST";
         case GS_FVG_RETEST: return "FVG_RETEST";
         case GS_STRUCTURE_CONTINUATION: return "STRUCTURE_CONTINUATION";
         case GS_CANDLE_REVERSAL: return "CANDLE_REVERSAL";
         case GS_DISPLACEMENT_REACTION: return "DISPLACEMENT_REACTION";
         case GS_MICRO_FLIP: return "MICRO_FLIP";
         case GS_ZONE_TO_ZONE: return "ZONE_TO_ZONE";
         default: return "NONE";
        }
     }

   void ResetCandidate(GoldCandidate &c)
     {
      c.setup = GS_NONE; c.direction = 0;
      c.coreScore = c.secondaryScore = c.totalScore = 0.0;
      c.ptsSetup = c.ptsLocation = c.ptsLiquidity = c.ptsStructure = c.ptsTrigger = c.ptsTargetRoom = 0.0;
      c.ptsMomentum = c.ptsVolume = c.ptsHTF = c.ptsSession = 0.0;
      c.keyLevel = c.entryZoneUpper = c.entryZoneLower = 0.0;
      c.suggestedSL = c.tp1 = c.tp2 = c.tp3 = c.tp4 = 0.0;
      c.tp3Valid = c.tp4Valid = false;
      c.roomState = ROOM_NONE;
      c.blockReason = "";
      c.fingerprint = "";
      c.barTime = 0;
      c.valid = false;
     }

   void ResetSignal(GoldScalpSignal &s)
     {
      s.valid = false; s.pass = false; s.direction = 0;
      s.setupType = GS_NONE; s.setupName = "NONE";
      s.score = s.coreScore = s.secondaryScore = 0.0;
      s.minScore = m_hfMode ? m_minTotalHF : m_minTotalHQ;
      s.ptsSetup = s.ptsLocation = s.ptsLiquidity = s.ptsStructure = s.ptsTrigger = s.ptsTargetRoom = 0.0;
      s.ptsMomentum = s.ptsVolume = s.ptsHTF = s.ptsSession = 0.0;
      s.ptsSR = s.ptsSweep = s.ptsCandle = s.ptsSmcBonus = 0.0;
      s.keyLevel = s.suggestedSL = s.entryPrice = 0.0;
      s.tp1 = s.tp2 = s.tp3 = s.tp4 = 0.0;
      s.tp3Valid = s.tp4Valid = false;
      s.roomState = ROOM_NONE;
      s.decision = "BLOCKED"; s.blockReason = ""; s.fingerprint = "";
      s.barTime = iTime(m_symbol, m_tf, 1);
     }

   void CandidateToSignal(const GoldCandidate &c, GoldScalpSignal &s)
     {
      s.valid = true;
      s.direction = c.direction;
      s.setupType = c.setup;
      s.setupName = SetupName(c.setup);
      s.score = c.totalScore;
      s.coreScore = c.coreScore;
      s.secondaryScore = c.secondaryScore;
      s.ptsSetup = c.ptsSetup; s.ptsLocation = c.ptsLocation;
      s.ptsLiquidity = c.ptsLiquidity; s.ptsStructure = c.ptsStructure;
      s.ptsTrigger = c.ptsTrigger; s.ptsTargetRoom = c.ptsTargetRoom;
      s.ptsMomentum = c.ptsMomentum; s.ptsVolume = c.ptsVolume;
      s.ptsHTF = c.ptsHTF; s.ptsSession = c.ptsSession;
      // legacy mapping
      s.ptsSR = c.ptsLocation; s.ptsSweep = c.ptsLiquidity;
      s.ptsCandle = c.ptsTrigger; s.ptsSmcBonus = 0.0;
      s.keyLevel = c.keyLevel;
      s.suggestedSL = c.suggestedSL;
      s.entryPrice = (c.direction > 0 ? SymbolInfoDouble(m_symbol, SYMBOL_ASK)
                                      : SymbolInfoDouble(m_symbol, SYMBOL_BID));
      s.tp1 = c.tp1; s.tp2 = c.tp2; s.tp3 = c.tp3; s.tp4 = c.tp4;
      s.tp3Valid = c.tp3Valid; s.tp4Valid = c.tp4Valid;
      s.roomState = c.roomState;
      s.fingerprint = c.fingerprint;
      s.barTime = c.barTime;
      s.blockReason = c.blockReason;
     }

   void OpenLog(void)
     {
      if(!m_log || m_logHandle != INVALID_HANDLE) return;
      bool exists = FileIsExist(m_logFile);
      m_logHandle = FileOpen(m_logFile, FILE_CSV|FILE_READ|FILE_WRITE|FILE_SHARE_READ|FILE_ANSI, ',');
      if(m_logHandle == INVALID_HANDLE) return;
      if(!exists)
        {
         FileWrite(m_logHandle,
                   "Time","Symbol","Setup","Dir","Core","Secondary","Total",
                   "Loc","Liq","Struct","Trig","Room","Mom","Vol","HTF","Sess",
                   "Decision","Reason","KeyLevel","SL","TP1","TP2");
         FileFlush(m_logHandle);
        }
      else FileSeek(m_logHandle, 0, SEEK_END);
     }

   void WriteLog(const GoldScalpSignal &s)
     {
      if(!m_log) return;
      OpenLog();
      if(m_logHandle == INVALID_HANDLE) return;
      FileWrite(m_logHandle,
                TimeToString(s.barTime, TIME_DATE|TIME_MINUTES),
                m_symbol, s.setupName, s.direction,
                s.coreScore, s.secondaryScore, s.score,
                s.ptsLocation, s.ptsLiquidity, s.ptsStructure, s.ptsTrigger, s.ptsTargetRoom,
                s.ptsMomentum, s.ptsVolume, s.ptsHTF, s.ptsSession,
                s.decision, s.blockReason, s.keyLevel, s.suggestedSL, s.tp1, s.tp2);
     }

public:
                     CGoldScalperEngine(void)
     {
      m_ready = false; m_logHandle = INVALID_HANDLE; m_log = false;
      m_logFile = "Dorando_GoldScalp_Diagnostics.csv";
      m_gen = m_passed = m_blocked = 0;
      m_candCount = m_noRoom = m_lowCore = m_lateEntry = 0;
      m_sessionTrades = 0; m_sessionDay = 0; m_lastTradeBar = 0;
      m_lastFingerprint = ""; m_lastFingerprintBar = 0;
      m_cooldownBars = 2; m_maxPerSession = 10;
      m_hfMode = true;                 // practical frequency by default
      m_coreHQ = 68.0; m_coreHF = 60.0;   // Phase 2.2 locked HF Core floor
      m_minTotalHQ = 62.0; m_minTotalHF = 54.0;
      m_useSweep = m_useRejection = m_useBO = m_useRange = true;
      m_useOB = m_useFVG = m_useStructCont = m_useCandle = true;
      m_useDisp = m_useMicro = m_useZoneToZone = true;
      m_sessionFilter = false;         // soft by default
      m_allowCounterHtf = true;
      ResetSignal(m_last);
     }

                    ~CGoldScalperEngine(void)
     {
      if(m_logHandle != INVALID_HANDLE) { FileClose(m_logHandle); m_logHandle = INVALID_HANDLE; }
     }

   bool Init(string symbol, ENUM_TIMEFRAMES tf,
             double minScore = 58.0,
             int cooldownBars = 2,
             int maxPerSession = 10,
             bool useSR = true, bool useBO = true, bool useSweep = true, bool useMicro = true,
             bool sessionFilter = false, bool allowCounterHtf = true)
     {
      m_symbol = symbol; m_tf = tf;
      // map legacy minScore into HF/HQ floors without over-filtering
      m_minTotalHF = MathMax(50.0, minScore - 4.0);
      m_minTotalHQ = MathMax(56.0, minScore);
      m_coreHF = 60.0;   // Phase 2.2 locked HF Core floor
      m_coreHQ = 68.0;   // Phase 2.2 locked HQ Core floor
      m_cooldownBars = MathMax(1, cooldownBars);
      m_maxPerSession = MathMax(1, maxPerSession);
      m_useRejection = useSR;
      m_useBO = useBO;
      m_useSweep = useSweep;
      m_useMicro = useMicro;
      m_sessionFilter = sessionFilter;
      m_allowCounterHtf = allowCounterHtf;
      m_hfMode = true; // preserve practical frequency
      m_ready = true;
      PrintFormat("GoldScalperEngine::Init %s %s HF=%s coreHF=%.0f coreHQ=%.0f (candidate-first, closed-bar)",
                  symbol, EnumToString(tf), (m_hfMode ? "Y" : "N"), m_coreHF, m_coreHQ);
      return true;
     }

   void SetLogging(bool on) { m_log = on; }
   void SetMinScore(double s)
     {
      m_minTotalHF = MathMax(50.0, s - 4.0);
      m_minTotalHQ = MathMax(56.0, s);
     }
   void SetHFMode(bool on) { m_hfMode = on; }
   void SetCoreFloors(double hq, double hf) { m_coreHQ = hq; m_coreHF = hf; }

   void NotifyTradeOpened(void)
     {
      m_lastTradeBar = iTime(m_symbol, m_tf, 0);
      m_sessionTrades++;
     }

   GoldScalpSignal Last(void) const { return m_last; }

   //+------------------------------------------------------------------+
   //| Main evaluation — candidate-first                                |
   //+------------------------------------------------------------------+
   GoldScalpSignal Evaluate(void)
     {
      GoldScalpSignal best;
      ResetSignal(best);
      if(!m_ready)
        {
         best.blockReason = "NOT_READY";
         m_last = best; return m_last;
        }

      // session day reset
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      datetime day = StringToTime(StringFormat("%04d.%02d.%02d", dt.year, dt.mon, dt.day));
      if(day != m_sessionDay) { m_sessionDay = day; m_sessionTrades = 0; }

      best.barTime = iTime(m_symbol, m_tf, 1);
      m_gen++;

      // hard safety: cooldown
      if(m_lastTradeBar > 0)
        {
         int barsSince = iBarShift(m_symbol, m_tf, m_lastTradeBar, true);
         if(barsSince >= 0 && barsSince < m_cooldownBars)
           {
            best.decision = "BLOCKED";
            best.blockReason = "COOLDOWN_ACTIVE";
            m_blocked++; WriteLog(best); m_last = best; return m_last;
           }
        }
      if(m_sessionTrades >= m_maxPerSession)
        {
         best.decision = "BLOCKED";
         best.blockReason = "SESSION_MAX_TRADES";
         m_blocked++; WriteLog(best); m_last = best; return m_last;
        }

      //----- CANDIDATE GENERATION (independent per family) -----
      GoldCandidate candidates[12];
      int nCand = 0;
      GoldCandidate tmp;

      if(m_useSweep) { ResetCandidate(tmp); if(DetectLiquiditySweep(tmp)) candidates[nCand++] = tmp; }
      if(m_useRejection)
        {
         ResetCandidate(tmp); if(DetectSupportRejection(tmp)) candidates[nCand++] = tmp;
         ResetCandidate(tmp); if(DetectResistanceRejection(tmp)) candidates[nCand++] = tmp;
        }
      if(m_useBO) { ResetCandidate(tmp); if(DetectBreakoutRetest(tmp)) candidates[nCand++] = tmp; }
      if(m_useRange) { ResetCandidate(tmp); if(DetectRangeBreak(tmp)) candidates[nCand++] = tmp; }
      if(m_useOB) { ResetCandidate(tmp); if(DetectOBRetest(tmp)) candidates[nCand++] = tmp; }
      if(m_useFVG) { ResetCandidate(tmp); if(DetectFVGRetest(tmp)) candidates[nCand++] = tmp; }
      if(m_useStructCont) { ResetCandidate(tmp); if(DetectStructureContinuation(tmp)) candidates[nCand++] = tmp; }
      if(m_useCandle) { ResetCandidate(tmp); if(DetectCandleReversal(tmp)) candidates[nCand++] = tmp; }
      if(m_useDisp) { ResetCandidate(tmp); if(DetectDisplacementReaction(tmp)) candidates[nCand++] = tmp; }
      if(m_useMicro) { ResetCandidate(tmp); if(DetectMicroFlip(tmp)) candidates[nCand++] = tmp; }
      if(m_useZoneToZone) { ResetCandidate(tmp); if(DetectZoneToZone(tmp)) candidates[nCand++] = tmp; }

      m_candCount += nCand;

      if(nCand == 0)
        {
         best.decision = "BLOCKED";
         best.blockReason = "NO_CANDIDATE";
         m_blocked++; WriteLog(best); m_last = best; return m_last;
        }

      //----- VALIDATE + SCORE EACH CANDIDATE -----
      GoldCandidate bestCand;
      ResetCandidate(bestCand);
      double bestQuality = -1.0;
      int bestPri = -1;

      for(int i = 0; i < nCand; i++)
        {
         GoldCandidate c = candidates[i];
         c.barTime = best.barTime;

         // target room
         EvaluateTargetRoom(c);
         if(c.roomState == ROOM_NONE)
           {
            c.blockReason = "NO_TARGET_ROOM";
            m_noRoom++;
            // still log later via best path if nothing else
            continue;
           }
         // marginal only allowed in HF
         if(c.roomState == ROOM_MARGINAL && !m_hfMode)
           {
            c.blockReason = "MARGINAL_ROOM_HQ_ONLY";
            continue;
           }

         // anti-chase
         if(!ApplyAntiChase(c))
           {
            c.blockReason = "LATE_ENTRY";
            m_lateEntry++;
            continue;
           }

         // core + secondary
         FillCoreAndTotal(c);

         // Core floor
         double coreFloor = m_hfMode ? m_coreHF : m_coreHQ;
         if(c.coreScore < coreFloor)
           {
            c.blockReason = "LOW_CORE_SCORE";
            m_lowCore++;
            continue;
           }

         // setup-specific total floor
         double totFloor = SetupSpecificTotalFloor(c.setup);
         if(c.totalScore < totFloor)
           {
            c.blockReason = "LOW_TOTAL_SCORE";
            continue;
           }

         // SL + TP
         ComputeSL(c);
         ComputeTPs(c);

         // basic SL validity
         double entry = iClose(m_symbol, m_tf, 1);
         if(c.direction > 0 && c.suggestedSL >= entry) { c.blockReason = "INVALID_SL"; continue; }
         if(c.direction < 0 && c.suggestedSL <= entry) { c.blockReason = "INVALID_SL"; continue; }

         c.fingerprint = StringFormat("%s|%d|%s|%.2f|%s",
                                      m_symbol, c.direction, SetupName(c.setup), c.keyLevel,
                                      TimeToString(c.barTime, TIME_DATE|TIME_MINUTES));
         c.valid = true;

         // ranking: Core-first quality, priority only as tie-breaker
         double quality = c.coreScore * 1.15 + c.secondaryScore * 0.35 + c.ptsTargetRoom * 0.5;
         int pri = SetupPriority(c.setup);
         if(quality > bestQuality + 0.05 ||
            (MathAbs(quality - bestQuality) <= 0.05 && pri > bestPri))
           {
            bestCand = c;
            bestQuality = quality;
            bestPri = pri;
           }
        }

      if(!bestCand.valid || bestCand.direction == 0)
        {
         best.decision = "BLOCKED";
         best.blockReason = (m_noRoom > 0 ? "NO_TARGET_ROOM" :
                             (m_lowCore > 0 ? "LOW_CORE_SCORE" : "NO_QUALIFIED_CANDIDATE"));
         m_blocked++; WriteLog(best); m_last = best; return m_last;
        }

      // duplicate check
      if(m_lastFingerprint == bestCand.fingerprint ||
         (m_lastFingerprint != "" && bestCand.setup == m_last.setupType &&
          bestCand.direction == m_last.direction &&
          MathAbs(bestCand.keyLevel - m_last.keyLevel) < ATR() * 0.12 &&
          m_lastFingerprintBar > 0 && iBarShift(m_symbol, m_tf, m_lastFingerprintBar, true) < m_cooldownBars))
        {
         best.decision = "BLOCKED";
         best.blockReason = "DUPLICATE_SETUP";
         m_blocked++; WriteLog(best); m_last = best; return m_last;
        }

      // PASS
      CandidateToSignal(bestCand, best);
      best.decision = "PASS";
      best.blockReason = "";
      best.pass = true;
      best.minScore = SetupSpecificTotalFloor(bestCand.setup);
      m_passed++;
      m_lastFingerprint = best.fingerprint;
      m_lastFingerprintBar = best.barTime;
      WriteLog(best);
      m_last = best;
      return m_last;
     }

   void LogSummary(void)
     {
      Print("========== Gold Scalper Diagnostics SUMMARY ==========");
      PrintFormat("Generated=%d Passed=%d Blocked=%d", m_gen, m_passed, m_blocked);
      PrintFormat("Candidates=%d NoRoom=%d LowCore=%d LateEntry=%d", m_candCount, m_noRoom, m_lowCore, m_lateEntry);
      PrintFormat("CSV: %s", m_logFile);
      Print("======================================================");
     }

   void Deinit(void)
     {
      LogSummary();
      if(m_logHandle != INVALID_HANDLE) { FileClose(m_logHandle); m_logHandle = INVALID_HANDLE; }
     }
  };

#endif
//+------------------------------------------------------------------+
