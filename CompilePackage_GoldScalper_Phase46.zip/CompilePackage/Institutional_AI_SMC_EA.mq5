//+------------------------------------------------------------------+
//|                                     Institutional_AI_SMC_EA.mq5  |
//|            Institutional AI SMC Autonomous Trading Engine MT5   |
//|                                                                    |
//|  Wires together all 14 Include modules built for this project.    |
//|  NOT COMPILED/TESTED — static authorship only, same caveat as      |
//|  every module before this one. This is the file with the most     |
//|  integration risk (fourteen modules meeting for the first time),  |
//|  so before live use: compile in MetaEditor, fix whatever surfaces,|
//|  then run on a demo account for a meaningful stretch before any   |
//|  real capital touches it.                                          |
//|                                                                    |
//|  PIPELINE (once per confirmed new bar):                            |
//|    Structure -> SMC/Liquidity -> Volume -> Regime -> Correlation   |
//|    -> SignalEngine score -> AI adjustment (optional) -> News gate  |
//|    -> Risk gate -> Execution -> TradeManager registration          |
//|                                                                    |
//|  EVERY TICK (not just new bar): RiskManager.Update(), TradeManager |
//|  .ManageAll() (partial TP/BE/trailing can trigger mid-bar), and a  |
//|  throttled Dashboard refresh.                                       |
//|                                                                    |
//|  TRADE CLOSURE is detected via OnTradeTransaction(), not by        |
//|  polling — this is the correct native MT5 mechanism and is what    |
//|  triggers JournalSystem.RecordTrade() and RiskManager              |
//|  .RecordTradeResult() with the real, final exit price.              |
//+------------------------------------------------------------------+
#property copyright "Institutional AI SMC Autonomous Trading Engine MT5"
#property version   "1.00"

#include <Trade/Trade.mqh>
#include <MarketStructureEngine.mqh>
#include <SmartMoneyEngine.mqh>
#include <VolumeEngine.mqh>
#include <MarketRegime.mqh>
#include <SignalEngine.mqh>
#include <RiskManager.mqh>
#include <TradeManager.mqh>
#include <ExecutionEngine.mqh>
#include <CorrelationEngine.mqh>
#include <JournalSystem.mqh>
#include <Dashboard.mqh>
#include <NewsFilter.mqh>
#include <AIEngine.mqh>
#include <OptimizationEngine.mqh>
#include <SymbolAdaptationEngine.mqh>
#include <StrategySelectorEngine.mqh>
#include <SupportResistanceEngine.mqh>
#include <PriceActionEngine.mqh>
#include <CandlestickEngine.mqh>
#include <ICTEngine.mqh>
#include <LiquidityHeatmapEngine.mqh>
#include <AITradeRankingEngine.mqh>
#include <AIRegimeEngine.mqh>
#include <AIAnomalyDetection.mqh>
#include <AIOptimizationEngine.mqh>
#include <RiskGovernor.mqh>
#include <IntelligenceHub.mqh>
#include <IntelligenceJournal.mqh>
#include <TradeIntelligenceDashboard.mqh>
#include <TradeAttributionEngine.mqh>
#include <ResearchAnalyticsEngine.mqh>
#include <BacktestDiagnosticEngine.mqh>
#include <ModeRouter.mqh>
#include <GoldScalperEngine.mqh>
#include <QualityVolumeEngine.mqh>
#include <SignalDiagnostics.mqh>
#include <SMCScenarioEngine.mqh>

//+------------------------------------------------------------------+
//| INPUTS                                                              |
//+------------------------------------------------------------------+
input group "=== General ==="
input ENUM_TIMEFRAMES InpExecutionTF        = PERIOD_M15;
input ENUM_TRADING_MODE InpTradingMode        = MODE_SMC;   // SMC | SCALP | AUTO
input bool            InpEnableGoldScalper  = false;   // Phase 4.6 Gold scalper entry engine
input ENUM_SCALP_SCORE_PRESET InpGoldScalpScorePreset = SCALP_SCORE_AGGRESSIVE; // HF-oriented default
input double          InpGoldScalpMinScore  = 55.0;    // practical floor (overridden by preset)
input bool            InpUseSRRejection     = true;
input bool            InpUseBreakoutRetest  = true;
input bool            InpUseLiquiditySweep  = true;
input bool            InpUseMicroTrend      = true;
input bool            InpGoldScalpSessionFilter = false; // soft by default — do not over-filter
input bool            InpAllowCounterHTF    = true;
input int             InpScalpCooldownBars  = 2;       // practical for M5/M15
input int             InpMaxScalpTradesPerSession = 10;
input bool            InpLogGoldScalpDiagnostics = false;
input bool            InpGoldScalpHFMode    = true;    // High Frequency path (CoreScore floor relaxed)

input bool            InpEnableSMCV2         = true;    // Phase 4.2 SMC scenario/entry-zone intelligence
input bool            InpEnableSignalDiagnostics = false; // Phase 4.5.1 signal+micro capital audit (observation only)
input bool            InpLogSMCV2            = false;   // Phase 4.2 log context/scenario/state
input double          InpSMCV2MinConfidence  = 60.0;    // MEDIUM floor for ENTRY_READY
input double          InpSMCV2MinRR          = 1.5;     // minimum RR to TP2
input ENUM_TIMEFRAMES InpHtfTF              = PERIOD_H4;
input long            InpMagicNumber        = 778241;
input int             InpBrokerGmtOffsetHours = 0;   // hours to add to server time ≈ UTC for sessions
input bool            InpRunSymbolProfileSelfTest = false; // logs classification self-test once on Init
input bool            InpLogStrategySelection = true;  // Phase 3.2 log-only strategy ranking (does not block trades)
input bool            InpLogSupportResistance = false; // Phase 3.3 log nearest S/R zones on event change
input bool            InpLogPriceAction = false;       // Phase 3.4 log PA pattern scores (diagnostic only)
input bool            InpLogCandlestick = false;       // Phase 3.5 log candle metrics/patterns (diagnostic only)
input bool            InpLogICT = false;              // Phase 3.6 log ICT snapshot (diagnostic only)
input bool            InpLogLiquidityHeatmap = false; // Phase 3.7 log liquidity confluence scores (not entry signals)
input bool            InpLogAITradeRank = false;      // Phase 3.8.1 log deterministic AI trade ranks (not signals)
input bool            InpLogAIRegime = false;         // Phase 3.8.2 log regime annotation (confidence ≠ trade probability)
input bool            InpLogAIAnomaly = false;        // Phase 3.8.3 log anomaly intensity (advisory only; does not block)
input bool            InpLogAIOptimization = false;   // Phase 3.8.4 log weight governance snapshot (no auto-tune)
input bool            InpLogRiskGovernor = false;     // Phase 3.9 log risk environment (advisory only; does not block)
input bool            InpLogIntelligenceHub = false;  // Phase 3.10 unified diagnostic snapshot (read-only; no trade coupling)
input bool            InpEnableIntelligenceJournal = false; // Phase 3.11 CSV export of intelligence snapshots (non-trading)
input bool            InpLogTradeDashboard = false;     // Phase 3.12 operator dashboard report (diagnostic only)
input bool            InpEnableTradeAttribution = false; // Phase 3.13 post-trade attribution capture/CSV (research only)
input bool            InpLogTradeAttribution = false;    // Phase 3.13 log attribution reports
input bool            InpEnableResearchAnalytics = false;  // Phase 3.14 offline research analytics
input bool            InpLogResearchAnalytics = false;     // Phase 3.14 log research report
input bool            InpRunResearchAnalyticsOnce = false; // Phase 3.14 run Analyze once on Init
input bool            InpEnableBacktestDiagnostic = false; // Phase 3.15 offline backtest diagnostic
input bool            InpLogBacktestDiagnostic = false;    // Phase 3.15 log diagnostic report
input bool            InpRunBacktestDiagnosticOnce = false; // Phase 3.15 run Analyze once on Init
input bool            InpEnableHtfBiasGate  = true;

input group "=== Structure / SMC ==="
input int             InpSwingLookback      = 3;
input int             InpAtrPeriod          = 14;
input double          InpFvgMinAtrMult      = 0.15;
input double          InpDispMinAtrMult     = 0.6;
input double          InpEqualTolAtrMult    = 0.15;
input int             InpObLookback         = 15;

input group "=== Volume / Regime ==="
input int             InpVolSmaPeriod       = 20;
input double          InpVolSpikeMult       = 1.5;
input int             InpAdxPeriod          = 14;
input double          InpAdxTrendMin        = 25.0;
input int             InpAtrBaselinePeriod  = 100;

input group "=== Signal Engine ==="
input int             InpRsiPeriod          = 14;

input group "=== Risk Management ==="
input double          InpBaseRiskPercent    = 1.0;
input bool            InpEnableQualityVolume = false; // Phase 4.5.7 quality→risk multiplier
input double          InpQVMaxMultiplier     = 1.25;  // hard max quality mult
input double          InpQVInstitutionalCap  = 1.10;  // SMC mode max mult
input double          InpQVMicroMaxMult      = 1.00;  // MICRO account max mult
input double          InpQVMaxRiskCapPct     = 2.0;   // effective risk % ceiling
input double          InpQVHighThreshold     = 90.0;
input double          InpQVNormalThreshold   = 70.0;
input double          InpQVMinQualityToTrade = 50.0;
input double          InpQVMicroEquityMax    = 500.0;
input double          InpQVSmallEquityMax    = 5000.0;
input bool            InpLogQualityVolume    = false;

input ENUM_ACCOUNT_PROFILE_MODE InpAccountProfile = ACCOUNT_PROFILE_AUTO; // Phase 4.5.2 AUTO/STANDARD/MICRO
input ENUM_MICRO_MIN_LOT_MODE   InpMicroMinLotMode = MICRO_MIN_LOT_OFF;   // OFF or SAFE_MIN_LOT (micro only)
input double          InpMicroEquityThreshold = 1000.0; // AUTO → MICRO below this equity
input double          InpMicroDailyLossPct = 2.5;       // tighter daily loss when MICRO
input int             InpMicroMaxOpenTrades = 1;        // max positions when MICRO

input double          InpMaxDailyLossPct    = 2.0;
input double          InpMaxDrawdownPct     = 8.0;
input int             InpMaxOpenTrades      = 3;
input double          InpMaxExposurePct     = 5.0;
input bool            InpAdaptiveRiskOn     = true;
input double          InpAdaptiveMinMult    = 0.5;
input double          InpAdaptiveMaxMult    = 1.5;
input double          InpAtrSlMult          = 1.8;
input double          InpSlBufferAtrMult    = 0.15;
input int             InpAdaptiveWindow     = 10;
input ENUM_SL_METHOD  InpSlMethod           = SL_SWING;

input group "=== Trade Management ==="
input bool            InpEnableSmartProfit  = true;     // Phase 4.3 post-entry lifecycle manager
input double          InpBreakEvenTrigger_R = 1.0;      // R-multiple to move SL to BE
input double          InpBE_BufferPoints    = 50;       // BE buffer in points
input bool            InpPartialCloseEnabled = true;
input double          InpPartial1Pct        = 25.0;
input double          InpPartial2Pct        = 25.0;
input double          InpPartial3Pct        = 25.0;
input ENUM_TRAIL_MODE InpTrailingMode       = TRAIL_ATR;
input double          InpTrailAtrMult       = 1.5;
input double          InpTrailAtrWeakMult   = 0.8;      // tighter trail when vol elevated
input int             InpStructureLookback  = 5;
input double          InpProfitLock_R       = 2.0;      // arm min-profit floor after this peak R
input double          InpMaximumGiveback_R  = 0.8;      // protected R after lock
input ENUM_MGMT_PROFILE InpMgmtProfile      = MGMT_INSTITUTIONAL; // INSTITUTIONAL | GOLD_SCALP | MICRO | AUTO
input bool            InpLogMgmtDiagnostics = false; // Phase 4.5.3 management event CSV

input group "=== Execution ==="
input double          InpMaxSpreadPoints    = 30.0;
input int             InpMaxSlippagePoints  = 10;

input group "=== Correlation ==="
input string          InpCorrelationWatchList = "";   // comma-separated symbols, e.g. "DXY,XAUUSD,US500" —
                                                          // left empty by default since symbol availability
                                                          // varies by broker; fill in what your broker offers
input double          InpCorrHighThreshold  = 0.6;

input group "=== News Filter ==="
input string          InpNewsWatchedCountries = "US";   // comma-separated ISO country codes
input int              InpNewsMinutesBefore    = 30;
input int              InpNewsMinutesAfter     = 30;
input bool             InpRequirePostNewsConfirm = true;

input group "=== AI Engine (optional) ==="
input string           InpAiServerUrl        = "";   // empty = permanently disabled, no network calls ever made
input int               InpAiTimeoutMs        = 2000;
input int               InpAiMaxInfluencePct  = 15;

//+------------------------------------------------------------------+
//| GLOBAL ENGINE INSTANCES                                             |
//+------------------------------------------------------------------+
CMarketStructureEngine g_struct;
CMarketStructureEngine g_htfStruct;
CSmartMoneyEngine      g_smc;
CVolumeEngine          g_volume;
CMarketRegime          g_regime;
CSignalEngine          g_signal;
CRiskManager           g_risk;
CTradeManager          g_tradeMgr;
CExecutionEngine       g_exec;
CCorrelationEngine     g_correlation;
CJournalSystem         g_journal;
CDashboard             g_dashboard;
CNewsFilter            g_news;
CAIEngine              g_ai;
COptimizationEngine    g_optimizer;
CSymbolAdaptationEngine g_symbolAdapt;
CStrategySelectorEngine  g_strategySelector;
CSupportResistanceEngine g_srEngine;
CPriceActionEngine       g_priceAction;
CCandlestickEngine       g_candles;
CICTEngine               g_ict;
CLiquidityHeatmapEngine  g_liqHeat;
CAITradeRankingEngine    g_aiRank;
CAIRegimeEngine          g_aiRegime;
CAIAnomalyDetection      g_aiAnomaly;
CAIOptimizationEngine    g_aiOptimization;
CRiskGovernor            g_riskGovernor;
CIntelligenceHub         g_intelligenceHub;
CIntelligenceJournal     g_intelligenceJournal;
CTradeIntelligenceDashboard g_tradeDashboard;
CTradeAttributionEngine  g_tradeAttr;
CResearchAnalyticsEngine g_researchAnalytics;
CBacktestDiagnosticEngine g_backtestDiag;
CModeRouter              g_modeRouter;
CGoldScalperEngine       g_goldScalper;
CQualityVolumeEngine     g_qualityVol;
CSignalDiagnostics       g_signalDiag;
CSMCScenarioEngine       g_smcScenario;

datetime               g_lastBarTime      = 0;
datetime               g_lastHtfBarTime   = 0;
bool                    g_useHtfBias      = false;
bool                    g_useCorrelation  = false;

//+------------------------------------------------------------------+
//| Per-open-trade metadata not owned by TradeManager (which only     |
//| tracks execution mechanics) — score/grade/regime/setup at entry,  |
//| needed by JournalSystem when the position eventually closes.       |
//| Keyed by position ticket, populated at open, consumed at close.    |
//+------------------------------------------------------------------+
struct PendingTradeMeta
  {
   ulong             ticket;
   double            score;
   string            grade;
   string            regime;
   string            setupType;
   datetime          entryTime;
   double            entryPrice;
   double            structureScore;
   double            obScore;
   double            fvgScore;
   double            liquidityScore;
   double            displacementScore;
   double            volumeScore;
   double            momentumScore;
   double            atrRatio;
   double            adx;
  };
PendingTradeMeta g_pendingMeta[];

void StorePendingMeta(ulong ticket, double score, string grade, string regime, string setupType, double entryPrice,
                       double structureScore, double obScore, double fvgScore, double liquidityScore,
                       double displacementScore, double volumeScore, double momentumScore,
                       double atrRatio, double adx)
  {
   int n = ArraySize(g_pendingMeta);
   ArrayResize(g_pendingMeta, n + 1);
   g_pendingMeta[n].ticket             = ticket;
   g_pendingMeta[n].score              = score;
   g_pendingMeta[n].grade              = grade;
   g_pendingMeta[n].regime             = regime;
   g_pendingMeta[n].setupType          = setupType;
   g_pendingMeta[n].entryTime          = TimeCurrent();
   g_pendingMeta[n].entryPrice         = entryPrice;
   g_pendingMeta[n].structureScore     = structureScore;
   g_pendingMeta[n].obScore            = obScore;
   g_pendingMeta[n].fvgScore           = fvgScore;
   g_pendingMeta[n].liquidityScore     = liquidityScore;
   g_pendingMeta[n].displacementScore  = displacementScore;
   g_pendingMeta[n].volumeScore        = volumeScore;
   g_pendingMeta[n].momentumScore      = momentumScore;
   g_pendingMeta[n].atrRatio           = atrRatio;
   g_pendingMeta[n].adx                = adx;
  }

bool TakePendingMeta(ulong ticket, PendingTradeMeta &out)
  {
   for(int i = 0; i < ArraySize(g_pendingMeta); i++)
     {
      if(g_pendingMeta[i].ticket == ticket)
        {
         out = g_pendingMeta[i];
         //--- remove it — consumed exactly once
         for(int j = i; j < ArraySize(g_pendingMeta) - 1; j++)
            g_pendingMeta[j] = g_pendingMeta[j + 1];
         ArrayResize(g_pendingMeta, ArraySize(g_pendingMeta) - 1);
         return true;
        }
     }
   return false;
  }

//+------------------------------------------------------------------+
void SplitCsv(string csv, string &out[])
  {
   ArrayResize(out, 0);
   if(StringLen(csv) == 0) return;
   int count = StringSplit(csv, ',', out);
   for(int i = 0; i < count; i++)
     {
      StringTrimLeft(out[i]);
      StringTrimRight(out[i]);
     }
  }

//+------------------------------------------------------------------+
bool IsNewBar(string symbol, ENUM_TIMEFRAMES tf, datetime &lastSeen)
  {
   datetime t = iTime(symbol, tf, 0);
   if(t != lastSeen)
     {
      lastSeen = t;
      return true;
     }
   return false;
  }

//+------------------------------------------------------------------+
int OnInit()
  {
   string symbol = _Symbol;

   //--- Phase 3.1: symbol profile detection (additive; does not override inputs yet)
   if(!g_modeRouter.Init(InpTradingMode, InpEnableGoldScalper))
     { Print("Init failed: ModeRouter"); return INIT_FAILED; }

   if(InpEnableGoldScalper)
     {
      double minSc = InpGoldScalpMinScore;
      if(InpGoldScalpScorePreset == SCALP_SCORE_AGGRESSIVE) minSc = 54.0;
      else if(InpGoldScalpScorePreset == SCALP_SCORE_NORMAL) minSc = 58.0;
      else if(InpGoldScalpScorePreset == SCALP_SCORE_CONSERVATIVE) minSc = 64.0;
      int cd = InpScalpCooldownBars;
      if(PeriodSeconds(InpExecutionTF) >= PeriodSeconds(PERIOD_M15) && cd > 2)
         cd = 2;
      if(!g_goldScalper.Init(symbol, InpExecutionTF, minSc, cd, InpMaxScalpTradesPerSession,
                             InpUseSRRejection, InpUseBreakoutRetest, InpUseLiquiditySweep, InpUseMicroTrend,
                             InpGoldScalpSessionFilter, InpAllowCounterHTF))
         Print("GoldScalperEngine init failed (non-fatal)");
      else
        {
         g_goldScalper.SetLogging(InpLogGoldScalpDiagnostics);
         g_goldScalper.SetHFMode(InpGoldScalpHFMode);
         g_modeRouter.SetScalperAvailable(true);
        }
     }

   if(InpEnableSignalDiagnostics)
     {
      if(!g_signalDiag.Init(symbol))
         Print("SignalDiagnostics unavailable (non-fatal)");
     }

   if(InpEnableSMCV2)
     {
      if(!g_smcScenario.Init(symbol, InpExecutionTF, InpSMCV2MinRR, 75.0, InpSMCV2MinConfidence, 48))
         Print("SMCScenarioEngine init failed (non-fatal)");
     }

   if(!g_symbolAdapt.Init(symbol, InpExecutionTF, InpBrokerGmtOffsetHours))
     { Print("Init failed: SymbolAdaptationEngine"); return INIT_FAILED; }
   if(InpRunSymbolProfileSelfTest)
      g_symbolAdapt.RunProfileSelfTest();

   if(!g_strategySelector.Init())
     { Print("Init failed: StrategySelectorEngine"); return INIT_FAILED; }
   // diagnostic only — failure to open journal must not block trading
   if(!g_strategySelector.InitJournal(symbol))
      Print("StrategySelector journal unavailable (non-fatal)");

   if(!g_srEngine.Init(symbol, InpExecutionTF, InpHtfTF))
     { Print("Init failed: SupportResistanceEngine"); return INIT_FAILED; }

   if(!g_priceAction.Init(symbol, InpExecutionTF, InpAtrPeriod))
     { Print("Init failed: PriceActionEngine"); return INIT_FAILED; }

   if(!g_candles.Init(symbol, InpExecutionTF, InpAtrPeriod))
     { Print("Init failed: CandlestickEngine"); return INIT_FAILED; }

   if(!g_ict.Init(symbol, InpExecutionTF, InpHtfTF, InpBrokerGmtOffsetHours))
     { Print("Init failed: ICTEngine"); return INIT_FAILED; }

   if(!g_liqHeat.Init(symbol, InpExecutionTF, InpBrokerGmtOffsetHours))
     { Print("Init failed: LiquidityHeatmapEngine"); return INIT_FAILED; }

   if(!g_aiRank.Init())
     { Print("Init failed: AITradeRankingEngine"); return INIT_FAILED; }

   if(!g_aiRegime.Init())
     { Print("Init failed: AIRegimeEngine"); return INIT_FAILED; }

   if(!g_aiAnomaly.Init(symbol, InpExecutionTF))
     { Print("Init failed: AIAnomalyDetection"); return INIT_FAILED; }

   if(!g_aiOptimization.Init(50))
     { Print("Init failed: AIOptimizationEngine"); return INIT_FAILED; }

   if(!g_riskGovernor.Init())
     { Print("Init failed: RiskGovernor"); return INIT_FAILED; }

   if(!g_intelligenceHub.Init(symbol))
     { Print("Init failed: IntelligenceHub"); return INIT_FAILED; }

   // journal export is optional — failure must not block trading
   if(InpEnableIntelligenceJournal)
     {
      if(!g_intelligenceJournal.Init(symbol))
         Print("IntelligenceJournal unavailable (non-fatal)");
      else
         g_intelligenceJournal.SetThrottle(60);
     }

   if(!g_tradeDashboard.Init())
     { Print("Init failed: TradeIntelligenceDashboard"); return INIT_FAILED; }

   if(InpEnableTradeAttribution)
     {
      if(!g_tradeAttr.Init(symbol))
         Print("TradeAttributionEngine unavailable (non-fatal)");
     }

   if(InpEnableResearchAnalytics)
     {
      if(!g_researchAnalytics.Init(symbol))
         Print("ResearchAnalyticsEngine unavailable (non-fatal)");
      else if(InpRunResearchAnalyticsOnce)
        {
         g_researchAnalytics.Analyze();
         if(InpLogResearchAnalytics)
            g_researchAnalytics.LogReport();
        }
     }

   if(InpEnableBacktestDiagnostic)
     {
      if(!g_backtestDiag.Init(symbol))
         Print("BacktestDiagnosticEngine unavailable (non-fatal)");
      else if(InpRunBacktestDiagnosticOnce)
        {
         g_backtestDiag.Analyze();
         g_backtestDiag.AssessScalping();
         if(InpLogBacktestDiagnostic)
            g_backtestDiag.LogReport();
        }
     }

   if(!g_struct.Init(symbol, InpExecutionTF, InpSwingLookback))
     { Print("Init failed: MarketStructureEngine"); return INIT_FAILED; }

   g_useHtfBias = InpEnableHtfBiasGate;
   if(g_useHtfBias && !g_htfStruct.Init(symbol, InpHtfTF, InpSwingLookback))
     { Print("Init failed: HTF MarketStructureEngine"); return INIT_FAILED; }

   if(!g_smc.Init(symbol, InpExecutionTF, InpAtrPeriod, InpFvgMinAtrMult, InpDispMinAtrMult,
                   InpEqualTolAtrMult, InpObLookback))
     { Print("Init failed: SmartMoneyEngine"); return INIT_FAILED; }

   if(!g_volume.Init(symbol, InpExecutionTF, InpVolSmaPeriod, InpVolSpikeMult))
     { Print("Init failed: VolumeEngine"); return INIT_FAILED; }

   if(!g_regime.Init(symbol, InpExecutionTF, InpAdxPeriod, InpAdxTrendMin, InpAtrPeriod, InpAtrBaselinePeriod))
     { Print("Init failed: MarketRegime"); return INIT_FAILED; }

   if(!g_signal.Init(symbol, InpExecutionTF, InpRsiPeriod))
     { Print("Init failed: SignalEngine"); return INIT_FAILED; }

   if(!g_risk.Init(symbol, InpExecutionTF, InpBaseRiskPercent, InpMaxDailyLossPct, InpMaxDrawdownPct,
                    InpMaxOpenTrades, InpMaxExposurePct, InpAdaptiveRiskOn, InpAdaptiveMinMult,
                    InpAdaptiveMaxMult, InpAtrPeriod, InpAtrSlMult, InpSlBufferAtrMult, InpAdaptiveWindow))
     { Print("Init failed: RiskManager"); return INIT_FAILED; }
   g_risk.ConfigureMicroPolicy(InpAccountProfile, InpMicroMinLotMode,
                                InpMicroEquityThreshold, InpMicroDailyLossPct, InpMicroMaxOpenTrades);
   g_qualityVol.Init(symbol, InpEnableQualityVolume,
                     InpQVHighThreshold, InpQVNormalThreshold,
                     InpQVMaxMultiplier, InpQVInstitutionalCap,
                     InpQVMicroEquityMax, InpQVSmallEquityMax,
                     InpQVMaxRiskCapPct, InpQVMicroMaxMult, InpQVMinQualityToTrade);
   g_qualityVol.SetLogging(InpLogQualityVolume);


   if(!g_tradeMgr.Init(symbol, InpExecutionTF, InpAtrPeriod))
     { Print("Init failed: TradeManager"); return INIT_FAILED; }
   g_tradeMgr.ConfigureSmartProfit(
      InpEnableSmartProfit,
      InpBreakEvenTrigger_R,
      InpBE_BufferPoints,
      InpPartialCloseEnabled,
      InpPartial1Pct, InpPartial2Pct, InpPartial3Pct,
      InpTrailingMode,
      InpTrailAtrMult,
      InpTrailAtrWeakMult,
      InpStructureLookback,
      InpProfitLock_R,
      InpMaximumGiveback_R,
      InpMgmtProfile);
   g_tradeMgr.SetMgmtLogging(InpLogMgmtDiagnostics);
   {
      ENUM_MGMT_PROFILE ep = g_tradeMgr.EffectiveProfile();
      string eps = "INSTITUTIONAL";
      if(ep == MGMT_GOLD_SCALP) eps = "GOLD_SCALP";
      else if(ep == MGMT_MICRO) eps = "MICRO";
      PrintFormat("SmartProfit effective profile: %s (Phase 4.5.5 adaptive protection)", eps);
   }

   if(!g_exec.Init(InpMagicNumber, InpMaxSpreadPoints, InpMaxSlippagePoints))
     { Print("Init failed: ExecutionEngine"); return INIT_FAILED; }

   g_useCorrelation = (StringLen(InpCorrelationWatchList) > 0);
   if(g_useCorrelation)
     {
      string watchList[];
      SplitCsv(InpCorrelationWatchList, watchList);
      if(!g_correlation.Init(symbol, InpExecutionTF, watchList, 100, InpCorrHighThreshold))
        { Print("Init failed: CorrelationEngine"); return INIT_FAILED; }
     }

   if(!g_journal.Init("InstitutionalAI_" + symbol + "_Journal.csv", 500))
     { Print("Init failed: JournalSystem"); return INIT_FAILED; }

   if(!g_dashboard.Init("InstAI_" + symbol, 0, 12, 30, 9, CORNER_LEFT_UPPER))
     { Print("Init failed: Dashboard"); return INIT_FAILED; }

   string newsCountries[];
   SplitCsv(InpNewsWatchedCountries, newsCountries);
   if(!g_news.Init(newsCountries, InpNewsMinutesBefore, InpNewsMinutesAfter,
                    CALENDAR_IMPORTANCE_HIGH, InpRequirePostNewsConfirm))
     { Print("Init failed: NewsFilter"); return INIT_FAILED; }

   if(!g_ai.Init(InpAiServerUrl, InpAiTimeoutMs, InpAiMaxInfluencePct))
     { Print("Init failed: AIEngine"); return INIT_FAILED; }

   g_optimizer.Init(0);   // outOfSampleStart=0 -> walk-forward splitting disabled by default;
                            // set via a future input if you want IS/OOS separation baked into
                            // live GenerateReport() calls, not just the Tester's own IS/OOS runs

   g_lastBarTime    = 0;
   g_lastHtfBarTime = 0;
   ArrayResize(g_pendingMeta, 0);

   PrintFormat("Institutional_AI_SMC_EA initialized on %s %s (HTF bias: %s, magic %d).",
               symbol, EnumToString(InpExecutionTF), g_useHtfBias ? EnumToString(InpHtfTF) : "disabled",
               InpMagicNumber);
   return INIT_SUCCEEDED;
  }

//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   g_intelligenceJournal.Deinit();
   g_tradeAttr.Deinit();
   g_researchAnalytics.Deinit();
   g_backtestDiag.Deinit();
   g_signalDiag.Deinit();
   g_goldScalper.Deinit();

   g_dashboard.Remove();
  }

//+------------------------------------------------------------------+
//| Runs the full decision pipeline for ONE direction. Returns true    |
//| if a trade was actually opened.                                    |

// Phase 4.5.7 — apply quality volume before lot sizing (does not change entry decision already made)
void ApplyQualityVolumeForLot(string setupType, double signalScore0to100, bool institutionalMode)
  {
   if(!InpEnableQualityVolume)
     {
      g_risk.ClearQualityRiskMultiplier();
      return;
     }
   double perf = g_risk.AdaptiveRiskMultiplier();
   QualityVolumeResult qv = g_qualityVol.Evaluate(
      signalScore0to100, setupType, g_regime, InpMaxSpreadPoints,
      InpBaseRiskPercent, perf, institutionalMode, 5.0);
   if(qv.decision == "BLOCKED")
     {
      g_risk.SetQualityRiskMultiplier(0.0, 0.0, false, InpQVMaxRiskCapPct);
      if(InpLogQualityVolume)
         g_qualityVol.LogDecision(qv, 0, SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN), 0, "N/A",
                                  institutionalMode ? "SMC" : "SCALP");
      return;
     }
   g_risk.SetQualityRiskMultiplier(qv.qualityMultiplier, qv.effectiveRiskPercent,
                                   g_qualityVol.AllowsSafeMinLot(), InpQVMaxRiskCapPct);
  }

//+------------------------------------------------------------------+
bool EvaluateAndMaybeTrade(bool isLong, string symbol)
  {
   CMarketStructureEngine *htfPtr = g_useHtfBias ? GetPointer(g_htfStruct) : NULL;
   SignalResult sig = g_signal.Evaluate(isLong, g_struct, g_smc, g_volume, g_regime, htfPtr);

   //--- Phase 4.4 helpers (observation only — does not change decisions)
   string dirStr = isLong ? "BUY" : "SELL";
   double px = SymbolInfoDouble(symbol, isLong ? SYMBOL_ASK : SYMBOL_BID);
   string regimeStr = g_regime.RegimeToString();
   double point = SymbolInfoDouble(symbol, SYMBOL_POINT);
   double spr = (point > 0 ? (SymbolInfoDouble(symbol, SYMBOL_ASK) - SymbolInfoDouble(symbol, SYMBOL_BID)) / point : 0);
   string spreadSt = (spr > InpMaxSpreadPoints ? "FAIL" : "OK");
   string htfSt = g_useHtfBias ? "GATE_ON" : "GATE_OFF";
   string sessSt = "N/A";
   string coolSt = "N/A";

   //--- Phase 4.2 SMC V2: scenario timing gates entry; soft score path
   bool smcV2Ready = false;
   SMCScenarioPlan v2plan;
   if(InpEnableSMCV2)
     {
      v2plan = g_smcScenario.Plan();
      int dir = isLong ? 1 : -1;
      string scenSt = v2plan.valid ? v2plan.stateName : "NO_PLAN";
      string scenTy = v2plan.valid ? v2plan.scenarioName : "None";
      string zoneSt = scenSt;
      string trigSt = (v2plan.triggerName != "" ? v2plan.triggerName : "NONE");
      string structSt = v2plan.valid ? v2plan.locationName : EnumToString(g_struct.LastEvent());
      string smcSt = (v2plan.valid ? "PLAN_OK" : "NO_PLAN");

      // WAITING_FOR_ZONE / not ready → do not chase even if legacy signal tradable
      if(v2plan.valid && v2plan.direction == dir)
        {
         if(v2plan.state == SMC_STATE_WAITING_FOR_ZONE ||
            v2plan.state == SMC_STATE_WATCHING ||
            v2plan.state == SMC_STATE_ZONE_REACHED)
           {
            if(g_signalDiag.IsEnabled())
               g_signalDiag.Log(dirStr, px, regimeStr, scenSt, scenTy, structSt, smcSt, zoneSt, trigSt,
                                v2plan.confidence, InpSMCV2MinConfidence, v2plan.rrTp2, InpSMCV2MinRR,
                                htfSt, sessSt, "N/A", spreadSt, coolSt, "N/A", "BLOCKED",
                                (v2plan.state == SMC_STATE_WAITING_FOR_ZONE ? "WAITING_FOR_ZONE" :
                                 (v2plan.state == SMC_STATE_ZONE_REACHED ? "NO_TRIGGER" : "WATCHING")));
            return false;
           }
         if(v2plan.state == SMC_STATE_INVALIDATED ||
            v2plan.state == SMC_STATE_EXPIRED ||
            v2plan.state == SMC_STATE_NO_SETUP)
           {
            if(g_signalDiag.IsEnabled())
               g_signalDiag.Log(dirStr, px, regimeStr, scenSt, scenTy, structSt, smcSt, zoneSt, trigSt,
                                v2plan.confidence, InpSMCV2MinConfidence, v2plan.rrTp2, InpSMCV2MinRR,
                                htfSt, sessSt, "N/A", spreadSt, coolSt, "N/A", "BLOCKED",
                                (v2plan.state == SMC_STATE_INVALIDATED ? "INVALIDATED" :
                                 (v2plan.state == SMC_STATE_EXPIRED ? "EXPIRED" : "NO_SETUP")));
            return false;
           }
         if(v2plan.entryReady && v2plan.state == SMC_STATE_ENTRY_READY &&
            v2plan.confidence >= InpSMCV2MinConfidence)
            smcV2Ready = true;
         else if(v2plan.state == SMC_STATE_ENTRY_READY && v2plan.confidence < InpSMCV2MinConfidence)
           {
            if(g_signalDiag.IsEnabled())
               g_signalDiag.Log(dirStr, px, regimeStr, scenSt, scenTy, structSt, smcSt, zoneSt, trigSt,
                                v2plan.confidence, InpSMCV2MinConfidence, v2plan.rrTp2, InpSMCV2MinRR,
                                htfSt, sessSt, "N/A", spreadSt, coolSt, "N/A", "BLOCKED", "CONFIDENCE_LOW");
            // fall through — smcV2Ready stays false → blocked below same as before
           }
        }
      else if(v2plan.valid && v2plan.direction != 0 && v2plan.direction != dir)
        {
         if(g_signalDiag.IsEnabled())
            g_signalDiag.Log(dirStr, px, regimeStr, scenSt, scenTy, structSt, smcSt, zoneSt, trigSt,
                             v2plan.confidence, InpSMCV2MinConfidence, v2plan.rrTp2, InpSMCV2MinRR,
                             htfSt, sessSt, "N/A", spreadSt, coolSt, "N/A", "BLOCKED", "OPPOSITE_SCENARIO");
         return false; // opposite scenario active — skip this direction
        }
      else if(!v2plan.valid || v2plan.scenario == SCENARIO_NO_TRADE)
        {
         if(g_signalDiag.IsEnabled())
            g_signalDiag.Log(dirStr, px, regimeStr, "NO_SCENARIO", "None", structSt, "NO_SCENARIO", "N/A", "N/A",
                             0, InpSMCV2MinConfidence, 0, InpSMCV2MinRR,
                             htfSt, sessSt, "N/A", spreadSt, coolSt, "N/A", "BLOCKED", "NO_SCENARIO");
         // same outcome: not ready
        }
     }

   // Legacy tradable still used when V2 disabled; when V2 ready, allow without full legacy tradable
   if(!InpEnableSMCV2)
     {
      if(!sig.tradable)
        {
         if(g_signalDiag.IsEnabled())
            g_signalDiag.Log(dirStr, px, regimeStr, "LEGACY", "None",
                             EnumToString(g_struct.LastEvent()), "LEGACY", "N/A", "N/A",
                             sig.score, 70.0, 0, 0, htfSt, sessSt, "N/A", spreadSt, coolSt, "N/A",
                             "BLOCKED", "LEGACY_NOT_TRADABLE");
         return false;
        }
     }
   else
     {
      if(!smcV2Ready)
        {
         // V2 enabled but not ENTRY_READY: Phase 4.2 policy unchanged
         if(g_signalDiag.IsEnabled())
           {
            string br = "NOT_ENTRY_READY";
            if(v2plan.valid)
              {
               if(v2plan.rrTp2 > 0 && v2plan.rrTp2 < InpSMCV2MinRR) br = "RR_INVALID";
               else if(v2plan.confidence < InpSMCV2MinConfidence) br = "CONFIDENCE_LOW";
               else br = "NOT_ENTRY_READY";
              }
            else br = "NO_SCENARIO";
            g_signalDiag.Log(dirStr, px, regimeStr,
                             (v2plan.valid ? v2plan.stateName : "NO_PLAN"),
                             (v2plan.valid ? v2plan.scenarioName : "None"),
                             (v2plan.valid ? v2plan.locationName : EnumToString(g_struct.LastEvent())),
                             (v2plan.valid ? "PLAN_OK" : "NO_PLAN"),
                             (v2plan.valid ? v2plan.stateName : "N/A"),
                             (v2plan.triggerName != "" ? v2plan.triggerName : "NONE"),
                             (v2plan.valid ? v2plan.confidence : sig.score),
                             InpSMCV2MinConfidence,
                             (v2plan.valid ? v2plan.rrTp2 : 0),
                             InpSMCV2MinRR,
                             htfSt, sessSt, "N/A", spreadSt, coolSt, "N/A", "BLOCKED", br);
           }
         return false;
        }
     }

   //--- AI adjustment (optional, bounded influence — see AIEngine.mqh header)
   AIFeatureSet features;
   features.structureScore    = sig.structurePts;
   features.obScore            = sig.obPts;
   features.fvgScore           = sig.fvgPts;
   features.liquidityScore     = sig.liquidityPts;
   features.displacementScore  = sig.displacementPts;
   features.volumeScore        = sig.volumePts;
   features.momentumScore      = sig.momentumPts;
   features.compositeScore     = sig.score;
   features.atrRatio           = g_regime.ATRRatio();
   features.adx                 = g_regime.ADX();
   features.regime              = g_regime.RegimeToString();
   features.isLong               = isLong;

   AIResult aiResult = g_ai.Query(features);
   double adjustedScore = sig.score;
   if(aiResult.available)
      adjustedScore = MathMax(0.0, MathMin(100.0, sig.score + aiResult.probabilityAdjustment * 100.0));
   //--- AIResult.probabilityAdjustment is -1..+1 (already bounded by
   //    AIEngine's own influence cap); scaling by 100 maps it onto the
   //    same 0-100 range SignalEngine's score uses, so it nudges rather
   //    than overrides the composite score.

   // Phase 4.2: when SMC V2 ENTRY_READY, confidence band replaces hard 70 floor
   if(InpEnableSMCV2 && smcV2Ready)
     {
      if(v2plan.confidence < InpSMCV2MinConfidence)
        {
         if(g_signalDiag.IsEnabled())
            g_signalDiag.Log(dirStr, px, regimeStr, v2plan.stateName, v2plan.scenarioName,
                             v2plan.locationName, "OK", v2plan.stateName, v2plan.triggerName,
                             v2plan.confidence, InpSMCV2MinConfidence, v2plan.rrTp2, InpSMCV2MinRR,
                             htfSt, sessSt, "N/A", spreadSt, coolSt, "N/A", "BLOCKED", "CONFIDENCE_LOW");
         return false;
        }
     }
   else if(adjustedScore < 70.0)
     {
      if(g_signalDiag.IsEnabled())
         g_signalDiag.Log(dirStr, px, regimeStr, "LEGACY", "LEGACY",
                          EnumToString(g_struct.LastEvent()), "LEGACY", "N/A", "N/A",
                          adjustedScore, 70.0, 0, 0, htfSt, sessSt, "N/A", spreadSt, coolSt, "N/A",
                          "BLOCKED", "CONFIDENCE_LOW");
      return false;
     }

   //--- news gate
   ENUM_NEWS_STATUS newsStatus = g_news.GetStatus();

   //--- NEWS_AWAITING_CONFIRMATION clears itself once a genuine post-news
   //    liquidity sweep + structure event is seen — that's exactly what
   //    SignalEngine's liquidityPts/structurePts already require to be
   //    nonzero for a tradable signal in the first place (sig.tradable
   //    was already checked above), so reaching this point at all means
   //    that evidence already exists. This MUST run before the blocking
   //    check below — placing it after would make it unreachable for the
   //    exact state it exists to clear.
   if(newsStatus == NEWS_AWAITING_CONFIRMATION && sig.liquidityPts > 0 && sig.structurePts > 0)
     {
      g_news.ConfirmPostNewsSetup();
      newsStatus = NEWS_CLEAR;   // re-evaluate locally rather than re-querying GetStatus()
                                    // a second time this tick, since it already ran its own
                                    // internal state-transition logic once above
     }

   if(newsStatus == NEWS_BLOCKED || newsStatus == NEWS_AWAITING_CONFIRMATION)
     {
      if(g_signalDiag.IsEnabled())
         g_signalDiag.Log(dirStr, px, regimeStr,
                          (InpEnableSMCV2 && v2plan.valid ? v2plan.stateName : "N/A"),
                          (InpEnableSMCV2 && v2plan.valid ? v2plan.scenarioName : "N/A"),
                          "N/A", "N/A", "N/A", "N/A",
                          (InpEnableSMCV2 && v2plan.valid ? v2plan.confidence : adjustedScore),
                          InpSMCV2MinConfidence, 0, InpSMCV2MinRR,
                          htfSt, sessSt, EnumToString(newsStatus), spreadSt, coolSt, "N/A",
                          "BLOCKED", "NEWS_BLOCK");
      return false;
     }

   double riskMultiplier = 1.0;
   if(newsStatus == NEWS_CAUTION)
      riskMultiplier = g_news.CautionRiskMultiplier();

   //--- stop loss
   double entryPrice = SymbolInfoDouble(symbol, isLong ? SYMBOL_ASK : SYMBOL_BID);
   double sl = g_risk.ComputeStopLoss(InpSlMethod, isLong, entryPrice, g_struct, g_smc);
   if(sl <= 0.0)
      sl = g_risk.ComputeStopLoss(SL_ATR, isLong, entryPrice, g_struct, g_smc);   // fallback — ATR always has a value
   if(sl <= 0.0)
      return false;   // even the ATR fallback failed (e.g. ATR handle not ready yet) — refuse rather than trade without a stop

   int digits = (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS);
   sl = NormalizeDouble(sl, digits);

   //--- risk gate
   double proposedRisk = AccountInfoDouble(ACCOUNT_EQUITY) * (InpBaseRiskPercent / 100.0)
                          * g_risk.AdaptiveRiskMultiplier() * riskMultiplier;
   if(!g_risk.CanOpenNewTrade(proposedRisk))
     {
      if(g_signalDiag.IsEnabled())
         g_signalDiag.Log(dirStr, px, regimeStr,
                          (InpEnableSMCV2 && v2plan.valid ? v2plan.stateName : "N/A"),
                          (InpEnableSMCV2 && v2plan.valid ? v2plan.scenarioName : "N/A"),
                          "N/A", "N/A", "N/A", "N/A",
                          (InpEnableSMCV2 && v2plan.valid ? v2plan.confidence : adjustedScore),
                          InpSMCV2MinConfidence, 0, InpSMCV2MinRR,
                          htfSt, sessSt, "OK", spreadSt, coolSt, "FAIL",
                          "BLOCKED", "RISK_LIMIT");
      return false;
     }

   //--- correlation gate
   if(g_useCorrelation)
     {
      string openSymbols[]; bool openIsLong[];
      int total = 0;
      ArrayResize(openSymbols, PositionsTotal());
      ArrayResize(openIsLong, PositionsTotal());
      for(int i = 0; i < PositionsTotal(); i++)
        {
         ulong t = PositionGetTicket(i);
         if(t == 0 || !PositionSelectByTicket(t)) continue;
         if((long)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber) continue;
         openSymbols[total] = PositionGetString(POSITION_SYMBOL);
         openIsLong[total]  = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
         total++;
        }
      ArrayResize(openSymbols, total);
      ArrayResize(openIsLong, total);
      if(g_correlation.WouldExceedCorrelatedExposure(openSymbols, openIsLong, isLong))
         return false;
     }

   //--- lot size (RiskManager internally reapplies its own effective
   //    risk%, matching the amount proposedRisk was estimated with)
   // Phase 4.2: prefer scenario invalidation SL when ENTRY_READY
   if(InpEnableSMCV2 && smcV2Ready && v2plan.invalidation > 0.0)
     {
      double v2sl = v2plan.invalidation;
      // direction sanity
      if(isLong && v2sl < entryPrice)
         sl = v2sl;
      if(!isLong && v2sl > entryPrice)
         sl = v2sl;
     }

   {
      double qScore = adjustedScore;
      if(InpEnableSMCV2 && v2plan.valid)
         qScore = v2plan.confidence;
      string setup = (InpEnableSMCV2 && v2plan.valid ? v2plan.scenarioName : sig.grade);
      ApplyQualityVolumeForLot(setup, qScore, true);
      if(InpEnableQualityVolume && g_qualityVol.Last().decision == "BLOCKED")
         return false;
   }
   double lots = g_risk.CalculateLotSize(entryPrice, sl);
   if(lots <= 0.0)
     {
      if(g_signalDiag.IsEnabled())
        {
         double bal = AccountInfoDouble(ACCOUNT_BALANCE);
         double eq  = AccountInfoDouble(ACCOUNT_EQUITY);
         double riskPct = InpBaseRiskPercent;
         double riskMoney = g_risk.LastRiskMoney();
         if(riskMoney <= 0) riskMoney = eq * (riskPct / 100.0) * g_risk.AdaptiveRiskMultiplier();
         double volMin = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
         double volStep = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);
         double margin = 0;
         OrderCalcMargin(isLong ? ORDER_TYPE_BUY : ORDER_TYPE_SELL, symbol, volMin, entryPrice, margin);
         string br = g_risk.LastLotReason();
         if(br == "") br = "LOT_BELOW_MIN_REJECTED";
         g_signalDiag.LogEx(dirStr, px, regimeStr,
                            (InpEnableSMCV2 && v2plan.valid ? v2plan.stateName : "N/A"),
                            (InpEnableSMCV2 && v2plan.valid ? v2plan.scenarioName : "N/A"),
                            "N/A", "N/A", "N/A", "N/A",
                            (InpEnableSMCV2 && v2plan.valid ? v2plan.confidence : adjustedScore),
                            InpSMCV2MinConfidence,
                            (InpEnableSMCV2 && v2plan.valid ? v2plan.rrTp2 : 0),
                            InpSMCV2MinRR,
                            htfSt, sessSt, "OK", spreadSt, coolSt, "OK",
                            bal, eq, riskPct, riskMoney,
                            g_risk.LastIdealLot(), volMin, volStep, margin,
                            "BLOCKED", br);
        }
      return false;
     }

   //--- Phase 4.5.1: log PASS with micro capital snapshot (observation only)
   if(g_signalDiag.IsEnabled())
     {
      double bal = AccountInfoDouble(ACCOUNT_BALANCE);
      double eq  = AccountInfoDouble(ACCOUNT_EQUITY);
      double volMin = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
      double volStep = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);
      double margin = 0;
      OrderCalcMargin(isLong ? ORDER_TYPE_BUY : ORDER_TYPE_SELL, symbol, lots, entryPrice, margin);
      g_signalDiag.LogEx(dirStr, px, regimeStr,
                         (InpEnableSMCV2 && v2plan.valid ? v2plan.stateName : "LEGACY"),
                         (InpEnableSMCV2 && v2plan.valid ? v2plan.scenarioName : "LEGACY"),
                         (InpEnableSMCV2 && v2plan.valid ? v2plan.locationName : EnumToString(g_struct.LastEvent())),
                         "OK", "READY", "OK",
                         (InpEnableSMCV2 && v2plan.valid ? v2plan.confidence : adjustedScore),
                         InpSMCV2MinConfidence,
                         (InpEnableSMCV2 && v2plan.valid ? v2plan.rrTp2 : 0),
                         InpSMCV2MinRR,
                         htfSt, sessSt, "OK", spreadSt, coolSt, "OK",
                         bal, eq, InpBaseRiskPercent, eq * (InpBaseRiskPercent / 100.0),
                         lots, volMin, volStep, margin,
                         "PASS", g_risk.LastLotReason());
     }

   //--- execute
   string comment = StringFormat("InstAI %s %.0f%%", sig.grade, sig.score);
   ExecutionOutcome outcome = g_exec.ExecuteMarketEntry(symbol, isLong, lots, sl, comment);
   if(outcome.result != EXEC_OK)
     {
      PrintFormat("Trade execution failed: %s", outcome.message);
      if(g_signalDiag.IsEnabled())
        {
         double bal = AccountInfoDouble(ACCOUNT_BALANCE);
         double eq  = AccountInfoDouble(ACCOUNT_EQUITY);
         double volMin = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
         double volStep = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);
         double margin = 0;
         OrderCalcMargin(isLong ? ORDER_TYPE_BUY : ORDER_TYPE_SELL, symbol, lots, entryPrice, margin);
         string br = "EXECUTION_FAILED";
         if(StringFind(outcome.message, "margin") >= 0 || StringFind(outcome.message, "Margin") >= 0)
            br = "MARGIN_FAILED";
         g_signalDiag.LogEx(dirStr, px, regimeStr,
                            (InpEnableSMCV2 && v2plan.valid ? v2plan.stateName : "N/A"),
                            (InpEnableSMCV2 && v2plan.valid ? v2plan.scenarioName : "N/A"),
                            "N/A", "N/A", "N/A", "N/A",
                            (InpEnableSMCV2 && v2plan.valid ? v2plan.confidence : adjustedScore),
                            InpSMCV2MinConfidence, 0, InpSMCV2MinRR,
                            htfSt, sessSt, "OK", spreadSt, coolSt, "OK",
                            bal, eq, InpBaseRiskPercent, eq * (InpBaseRiskPercent / 100.0),
                            lots, volMin, volStep, margin,
                            "BLOCKED", br);
        }
      return false;
     }

   //--- TP1-4 from the SmartMoneyEngine's nearest opposite-side levels,
   //    falling back to R-multiples off the actual fill price/SL if a
   //    structural level isn't available
   double riskDist = MathAbs(outcome.filledPrice - sl);
   double tTop, tBot; int mit;
   double tp1 = isLong ? outcome.filledPrice + riskDist * 1.5 : outcome.filledPrice - riskDist * 1.5;
   double tp2 = isLong ? outcome.filledPrice + riskDist * 2.5 : outcome.filledPrice - riskDist * 2.5;
   double tp3 = isLong ? outcome.filledPrice + riskDist * 4.0 : outcome.filledPrice - riskDist * 4.0;
   double tp4 = isLong ? outcome.filledPrice + riskDist * 6.0 : outcome.filledPrice - riskDist * 6.0;

   g_tradeMgr.RegisterPosition(outcome.ticket, symbol, isLong, outcome.filledPrice, outcome.filledVolume,
                                sl, tp1, tp2, tp3, tp4);

   string setupType = sig.obGrade == "A+" ? "OB_RETEST" : (sig.liquidityPts > 0 ? "LIQUIDITY_SWEEP" : "STRUCTURE_BREAK");
   StorePendingMeta(outcome.ticket, adjustedScore, sig.grade, g_regime.RegimeToString(), setupType, outcome.filledPrice,
                     sig.structurePts, sig.obPts, sig.fvgPts, sig.liquidityPts, sig.displacementPts,
                     sig.volumePts, sig.momentumPts, g_regime.ATRRatio(), g_regime.ADX());

   //--- Phase 3.13: attribution capture ONLY after confirmed successful open
   if(InpEnableTradeAttribution)
     {
      g_tradeAttr.CaptureEntry(outcome.ticket, symbol, isLong, outcome.filledPrice,
                               adjustedScore, sig.grade,
                               g_intelligenceHub.Last(), g_riskGovernor.Last());
     }


   PrintFormat("OPENED %s %s: %.5f lots @ %.5f, SL %.5f, score %.1f (%s)",
               isLong ? "LONG" : "SHORT", symbol, outcome.filledVolume, outcome.filledPrice, sl, adjustedScore, sig.grade);

   return true;
  }


//+------------------------------------------------------------------+
//| Phase 4.5.4 — Gold scalper entry path (does not use SMC V2 gate)  |
//+------------------------------------------------------------------+
bool EvaluateGoldScalpTrade(string symbol)
  {
   GoldScalpSignal gs = g_goldScalper.Evaluate();
   if(!gs.pass)
      return false;

   bool isLong = (gs.direction > 0);

   // spread
   double point = SymbolInfoDouble(symbol, SYMBOL_POINT);
   double spr = (point > 0 ? (SymbolInfoDouble(symbol, SYMBOL_ASK) - SymbolInfoDouble(symbol, SYMBOL_BID)) / point : 0);
   if(spr > InpMaxSpreadPoints)
     {
      if(InpLogGoldScalpDiagnostics)
         PrintFormat("GoldScalp BLOCKED SPREAD_TOO_HIGH spr=%.1f", spr);
      return false;
     }

   ENUM_NEWS_STATUS newsStatus = g_news.GetStatus();
   if(newsStatus == NEWS_BLOCKED || newsStatus == NEWS_AWAITING_CONFIRMATION)
      return false;

   double entryPrice = isLong ? SymbolInfoDouble(symbol, SYMBOL_ASK) : SymbolInfoDouble(symbol, SYMBOL_BID);
   double sl = gs.suggestedSL;
   if(sl <= 0)
      sl = g_risk.ComputeStopLoss(SL_ATR, isLong, entryPrice, g_struct, g_smc);
   int digits = (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS);
   sl = NormalizeDouble(sl, digits);
   if(isLong && sl >= entryPrice) return false;
   if(!isLong && sl <= entryPrice) return false;

   double riskMultiplier = 1.0;
   if(newsStatus == NEWS_CAUTION)
      riskMultiplier = g_news.CautionRiskMultiplier();
   double proposedRisk = AccountInfoDouble(ACCOUNT_EQUITY) * (InpBaseRiskPercent / 100.0)
                          * g_risk.AdaptiveRiskMultiplier() * riskMultiplier;
   if(!g_risk.CanOpenNewTrade(proposedRisk))
      return false;

   ApplyQualityVolumeForLot(gs.setupName, gs.score, false);
   if(InpEnableQualityVolume && g_qualityVol.Last().decision == "BLOCKED")
      return false;

   double lots = g_risk.CalculateLotSize(entryPrice, sl);
   if(lots <= 0.0)
      return false;

   // Force GOLD_SCALP management on these entries
   // (Configure already may be institutional — re-apply scalp profile for management)
   g_tradeMgr.ConfigureSmartProfit(
      InpEnableSmartProfit,
      0.7, InpBE_BufferPoints, InpPartialCloseEnabled,
      50.0, 25.0, 0.0,
      TRAIL_HYBRID, 1.0, 0.6, InpStructureLookback,
      1.1, 0.5, MGMT_GOLD_SCALP);

   string comment = StringFormat("GoldScalp %s %.0f", gs.setupName, gs.score);
   ExecutionOutcome outcome = g_exec.ExecuteMarketEntry(symbol, isLong, lots, sl, comment);
   if(outcome.result != EXEC_OK)
     {
      PrintFormat("GoldScalp execution failed: %s", outcome.message);
      return false;
     }

   // Prefer structure/liquidity-aware TPs from the engine; fall back to practical R multiples
   double riskDist = MathAbs(outcome.filledPrice - sl);
   if(riskDist <= 0.0) riskDist = SymbolInfoDouble(symbol, SYMBOL_POINT) * 200.0;
   double tp1 = gs.tp1;
   double tp2 = gs.tp2;
   double tp3 = gs.tp3Valid ? gs.tp3 : 0.0;
   double tp4 = gs.tp4Valid ? gs.tp4 : 0.0;
   if(tp1 <= 0.0)
      tp1 = isLong ? outcome.filledPrice + riskDist * 0.80 : outcome.filledPrice - riskDist * 0.80;
   if(tp2 <= 0.0)
      tp2 = isLong ? outcome.filledPrice + riskDist * 1.45 : outcome.filledPrice - riskDist * 1.45;
   if(tp3 <= 0.0)
      tp3 = isLong ? outcome.filledPrice + riskDist * 2.20 : outcome.filledPrice - riskDist * 2.20;
   if(tp4 <= 0.0)
      tp4 = isLong ? outcome.filledPrice + riskDist * 3.40 : outcome.filledPrice - riskDist * 3.40;

   g_tradeMgr.RegisterPosition(outcome.ticket, symbol, isLong, outcome.filledPrice, outcome.filledVolume,
                                sl, tp1, tp2, tp3, tp4);
   g_goldScalper.NotifyTradeOpened();

   PrintFormat("OPENED SCALP %s %s: %.5f lots @ %.5f SL %.5f Core %.0f Total %.0f (%s)",
               isLong ? "LONG" : "SHORT", symbol, outcome.filledVolume, outcome.filledPrice, sl,
               gs.coreScore, gs.score, gs.setupName);
   return true;
  }

//+------------------------------------------------------------------+
void RunPipeline(string symbol)
  {
   //--- dependency order matters: each engine below reads output from
   //    the ones listed before it
   g_struct.OnNewBar();
   g_smc.OnNewBar(g_struct);
   g_ict.OnNewBar(g_struct, g_smc);
   g_volume.OnNewBar();
   g_srEngine.OnNewBar(g_volume);
   // liquidity map after ICT/SMC/SR updates (diagnostic scores only)
   g_liqHeat.OnNewBar();
   g_liqHeat.EnrichFromICT(g_ict.Snapshot());
   g_liqHeat.EnrichFromSMC(g_smc);
   g_liqHeat.EnrichFromSR(g_srEngine);

   //--- Phase 4.2: SMC V2 scenario/entry-zone (does not replace modules)
   if(InpEnableSMCV2)
     {
      CMarketStructureEngine *htfPtrSc = g_useHtfBias ? GetPointer(g_htfStruct) : NULL;
      g_smcScenario.OnNewBar(g_struct, htfPtrSc, g_smc, g_srEngine, g_volume, g_regime, g_symbolAdapt);
      static string s_lastSmcV2 = "";
      if(InpLogSMCV2)
        {
         SMCScenarioPlan pl = g_smcScenario.Plan();
         string key = pl.scenarioName + ":" + pl.stateName + StringFormat(":%.0f", pl.confidence);
         if(key != s_lastSmcV2)
           {
            g_smcScenario.LogPlan();
            s_lastSmcV2 = key;
           }
        }
     }

   g_regime.OnNewBar(g_volume);
   if(g_useCorrelation)
      g_correlation.OnNewBar();

   if(IsNewBar(symbol, InpHtfTF, g_lastHtfBarTime) && g_useHtfBias)
      g_htfStruct.OnNewBar();

   
   //--- Phase 3.2: strategy ranking (log-only — does not gate entries)
   {
      StrategySelection sel = g_strategySelector.Evaluate(g_regime, g_struct, g_volume, g_symbolAdapt);
      static ENUM_STRATEGY_ID s_lastPrimary = STRAT_NONE;
      static string s_lastRegime = "";
      if(sel.valid && (sel.primary != s_lastPrimary || sel.regimeLabel != s_lastRegime))
        {
         // always journal strategy changes (diagnostic CSV for future AI)
         g_strategySelector.JournalLastSelection();
         if(InpLogStrategySelection)
            g_strategySelector.LogLastSelection();
         s_lastPrimary = sel.primary;
         s_lastRegime = sel.regimeLabel;
        }
   }

   if(InpLogSupportResistance)
     {
      static ENUM_SR_EVENT s_lastSrEvent = SR_EVENT_NONE;
      ENUM_SR_EVENT ev = g_srEngine.LastEvent();
      if(ev != SR_EVENT_NONE && ev != s_lastSrEvent)
        {
         g_srEngine.LogSnapshot();
         s_lastSrEvent = ev;
        }
     }

   //--- Phase 3.4: price-action scoring (diagnostic only — does not create trades)
   {
      PASignal pa = g_priceAction.EvaluateWithContext(g_struct, g_smc, g_srEngine, g_volume);
      static string s_lastPaKey = "";
      if(InpLogPriceAction && pa.valid)
        {
         string key = pa.name + ":" + pa.grade;
         if(key != s_lastPaKey)
           {
            g_priceAction.LogLast();
            s_lastPaKey = key;
           }
        }
   }

   //--- Phase 3.5: candlestick metrics (diagnostic metadata only — not trade signals)
   {
      CandleSignal cs = g_candles.Evaluate();
      static string s_lastCandleKey = "";
      if(InpLogCandlestick && cs.valid)
        {
         string key = cs.patternName + ":" + cs.grade + StringFormat(":%.0f", cs.metrics.quality);
         if(key != s_lastCandleKey)
           {
            g_candles.LogLast();
            s_lastCandleKey = key;
           }
        }
   }

   //--- Phase 3.8.3: anomaly intensity (advisory only — does not block trades or change risk)
   {
      AIAnomalyReport ar = g_aiAnomaly.Evaluate(g_volume, g_regime, g_symbolAdapt);
      static int s_lastAnomFlags = -1;
      static int s_lastSevBucket = -1;
      if(InpLogAIAnomaly && ar.valid)
        {
         int bucket = (int)(ar.severity / 10.0);
         if(ar.flags != s_lastAnomFlags || bucket != s_lastSevBucket)
           {
            g_aiAnomaly.LogLast();
            s_lastAnomFlags = ar.flags;
            s_lastSevBucket = bucket;
           }
        }
   }

   //--- Phase 3.8.2: regime annotation (does not modify MarketRegime; confidence ≠ trade probability)
   {
      AIRegimeAssessment regA = g_aiRegime.Evaluate(g_regime, g_struct, g_volume);
      static string s_lastAiReg = "";
      if(regA.valid)
        {
         string key = regA.labelName + StringFormat(":%.0f", regA.confidence);
         bool flipped = (s_lastAiReg != "" && StringFind(s_lastAiReg, regA.labelName) != 0);
         // detect label change: previous key starts with different label
         if(s_lastAiReg != "")
           {
            string prevLabel = s_lastAiReg;
            int colon = StringFind(prevLabel, ":");
            if(colon > 0)
               prevLabel = StringSubstr(prevLabel, 0, colon);
            flipped = (prevLabel != regA.labelName);
           }
         else
            flipped = false;
         g_aiOptimization.ObserveRegimeFlip(flipped);
         if(InpLogAIRegime && key != s_lastAiReg)
           {
            g_aiRegime.LogLast();
            s_lastAiReg = key;
           }
         else if(key != s_lastAiReg)
            s_lastAiReg = key;
        }
   }


   //--- Phase 3.9: risk environment report (metadata only — does not block or change risk)
   {
      RiskEnvironmentReport env = g_riskGovernor.Evaluate(
         g_risk, g_aiAnomaly, g_aiRegime, g_liqHeat, g_symbolAdapt);
      static string s_lastGovKey = "";
      if(InpLogRiskGovernor && env.valid)
        {
         string key = env.statusName + StringFormat(":%.0f", env.riskScore);
         if(key != s_lastGovKey)
           {
            g_riskGovernor.LogLast();
            s_lastGovKey = key;
           }
        }
   }

   //--- Phase 3.10: unified intelligence snapshot (read-only aggregate; no trade coupling)
   {
      IntelligenceSnapshot intel = g_intelligenceHub.Build(
         g_symbolAdapt, g_strategySelector, g_srEngine, g_priceAction, g_candles,
         g_ict, g_liqHeat, g_aiRank, g_aiRegime, g_aiAnomaly, g_aiOptimization, g_riskGovernor);
      static string s_lastIntelKey = "";
      if(InpLogIntelligenceHub && intel.valid)
        {
         string key = intel.healthName + ":" + intel.riskStatus + StringFormat(":%.0f", intel.riskScore);
         if(key != s_lastIntelKey)
           {
            g_intelligenceHub.LogLast();
            s_lastIntelKey = key;
           }
        }
      if(InpEnableIntelligenceJournal && intel.valid && g_intelligenceJournal.IsEnabled())
         g_intelligenceJournal.Write(intel);

      //--- Phase 3.12: operator dashboard (diagnostic only — no trade coupling)
      {
         TradeIntelligenceReport dash = g_tradeDashboard.Generate(
            intel,
            g_riskGovernor.Last(),
            g_aiAnomaly.Last(),
            g_aiRegime.Last(),
            g_liqHeat.Snapshot());
         static string s_lastDashKey = "";
         if(InpLogTradeDashboard && dash.valid)
           {
            string key = dash.systemHealth.statusName + ":" + dash.riskEnvironment;
            if(key != s_lastDashKey)
              {
               g_tradeDashboard.LogReport();
               s_lastDashKey = key;
              }
           }
      }
   }

   //--- Phase 3.8.1: deterministic trade ranking (diagnostic only — does not execute)
   {
      PASignal pa = g_priceAction.Last();
      CandleSignal cs = g_candles.Last();
      StrategySelection strat = g_strategySelector.Last();
      LiquidityHeatmapSnapshot liq = g_liqHeat.Snapshot();
      ICTSnapshot ict = g_ict.Snapshot();
      TradeRank rkL = g_aiRank.Evaluate(true,  g_struct, g_regime, g_volume, liq, ict, pa, cs, strat, g_news);
      TradeRank rkS = g_aiRank.Evaluate(false, g_struct, g_regime, g_volume, liq, ict, pa, cs, strat, g_news);
      static string s_lastRankKey = "";
      // weight governance observations only — does not SetWeights or trade
      if(rkL.valid)
         g_aiOptimization.ObserveRank(rkL);
      if(rkS.valid)
         g_aiOptimization.ObserveRank(rkS);

      if(InpLogAITradeRank && rkL.valid && rkS.valid)
        {
         string key = StringFormat("L%.0f%s_S%.0f%s", rkL.finalScore, rkL.grade, rkS.finalScore, rkS.grade);
         if(key != s_lastRankKey)
           {
            g_aiRank.LogRank(rkL);
            g_aiRank.LogRank(rkS);
            s_lastRankKey = key;
           }
        }

      if(InpLogAIOptimization)
        {
         static int s_lastOptSamples = -1;
         AIOptSnapshot snap = g_aiOptimization.Snapshot(g_aiRank);
         if(snap.valid && snap.metrics.rankSamples != s_lastOptSamples &&
            (snap.metrics.rankSamples % 10 == 0 || snap.metrics.dataSufficient))
           {
            g_aiOptimization.LogSnapshot(snap);
            AIOptSuggestion sug = g_aiOptimization.SuggestWeights(g_aiRank);
            g_aiOptimization.LogSuggestion(sug);
            s_lastOptSamples = snap.metrics.rankSamples;
           }
        }
   }

   //--- Phase 3.6: ICT snapshot (diagnostic only — not wired to signal/risk/exec)
   if(InpLogICT)
     {
      static string s_lastIctKey = "";
      ICTSnapshot ict = g_ict.Snapshot();
      if(ict.valid)
        {
         string key = ict.biasName + (ict.ote.valid ? ":OTE" : ":noOTE");
         if(key != s_lastIctKey)
           {
            g_ict.LogSnapshot();
            s_lastIctKey = key;
           }
        }
     }

   //--- Phase 3.7: liquidity confluence scores (diagnostic only — not entry probability)
   if(InpLogLiquidityHeatmap)
     {
      static int s_lastLiqCount = -1;
      LiquidityHeatmapSnapshot lhs = g_liqHeat.Snapshot();
      if(lhs.valid && lhs.nodeCount != s_lastLiqCount)
        {
         g_liqHeat.LogSnapshot();
         s_lastLiqCount = lhs.nodeCount;
        }
     }


if(!g_regime.IsTradingSuitable())
      return;   // Module 1's "if market conditions are not suitable: NO TRADE" gate

   //--- try long first, then short — ExecutionEngine's own duplicate-order
   //    guard (checked per-direction inside EvaluateAndMaybeTrade via
   //    ExecuteMarketEntry) prevents stacking a second same-direction
   //    position regardless, so no separate open-position scan is needed
   //    here; this ordering just decides which direction gets first
   //    refusal on a bar where (hypothetically) both somehow qualified
   //--- Phase 4.1: resolve trading mode (informational; entries remain SMC pipeline)
   {
      ENUM_TRADING_MODE activeMode = g_modeRouter.Resolve(symbol, InpExecutionTF);
      static string s_lastModeLog = "";
      string modeStr = g_modeRouter.ModeToString(activeMode);
      if(modeStr != s_lastModeLog)
        {
         PrintFormat("Current Trading Mode: %s", modeStr);
         s_lastModeLog = modeStr;
        }
   }

   // Phase 4.5.4: route by active mode — SCALP uses GoldScalperEngine only
   ENUM_TRADING_MODE tradeMode = g_modeRouter.ActiveMode();
   if(tradeMode == MODE_SCALP && InpEnableGoldScalper)
      EvaluateGoldScalpTrade(symbol);
   else
     {
      if(!EvaluateAndMaybeTrade(true, symbol))
         EvaluateAndMaybeTrade(false, symbol);
     }
  }

//+------------------------------------------------------------------+
void UpdateDashboard(string symbol)
  {
   DashboardData d;
   d.symbol            = symbol;
   d.marketBias        = g_struct.IsBullishStructure() ? "Bullish" : (g_struct.IsBearishStructure() ? "Bearish" : "Neutral");
   d.trend              = d.marketBias;
   d.structureStatus    = g_struct.EventToString(g_struct.LastEvent());
   d.smcSetup            = g_smc.DisplacementThisBar() ? "Displacement Active" : "Monitoring";
   d.aiConfidence        = 0.0;
   d.signalGrade         = "--";
   d.entry = d.sl = d.tp1 = d.tp2 = d.tp3 = d.tp4 = d.riskReward = 0.0;

   //--- reflect the currently open position, if any, rather than a
   //    hypothetical signal — the dashboard should describe reality
   for(int i = 0; i < PositionsTotal(); i++)
     {
      ulong t = PositionGetTicket(i);
      if(t == 0 || !PositionSelectByTicket(t)) continue;
      if((long)PositionGetInteger(POSITION_MAGIC) != InpMagicNumber) continue;
      if(PositionGetString(POSITION_SYMBOL) != symbol) continue;

      d.entry = PositionGetDouble(POSITION_PRICE_OPEN);
      d.sl    = PositionGetDouble(POSITION_SL);
      //--- KNOWN GAP: TP1-4/RR are left at 0 ("--" on the dashboard) here.
      //    TradeManager owns the TP1-4 levels internally per-ticket (set
      //    at RegisterPosition) but doesn't currently expose a getter for
      //    them — ActivePlanCount() is its only public introspection
      //    method. Rather than duplicate a second TP1-4 store in this
      //    file (which is exactly the kind of drift-prone parallel state
      //    caught and removed from OptimizationEngine.mqh earlier in this
      //    build), this is left honestly unfilled until TradeManager gets
      //    a small GetPlan(ticket, out TradePlan)-style accessor added.
      break;
     }

   d.newsStatus    = (g_news.GetStatus() == NEWS_CLEAR) ? "Clear" : (g_news.GetStatus() == NEWS_CAUTION ? "Caution" : "Blocked");
   d.marketRegime   = g_regime.RegimeToString();
   d.volumeStatus   = g_volume.IsVolumeSpike() ? "Strong" : "Weak";
   d.killSwitchActive = g_risk.IsKillSwitchActive();

   g_dashboard.Update(d);
  }

//+------------------------------------------------------------------+
void OnTick()
  {
   string symbol = _Symbol;

   g_risk.Update();
   g_tradeMgr.ManageAll();

   static datetime lastDashboardUpdate = 0;
   if(TimeCurrent() - lastDashboardUpdate >= 5)   // throttled — no need to redraw every tick
     {
      UpdateDashboard(symbol);
      lastDashboardUpdate = TimeCurrent();
     }

   if(IsNewBar(symbol, InpExecutionTF, g_lastBarTime))
      RunPipeline(symbol);
  }

//+------------------------------------------------------------------+
//| Native trade-closure detection — the correct MT5 mechanism,        |
//| independent of TradeManager's own internal plan cleanup.           |
//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans, const MqlTradeRequest &request, const MqlTradeResult &result)
  {
   if(trans.type != TRADE_TRANSACTION_DEAL_ADD)
      return;
   if(!HistoryDealSelect(trans.deal))
      return;

   long magic = HistoryDealGetInteger(trans.deal, DEAL_MAGIC);
   if(magic != InpMagicNumber)
      return;

   ENUM_DEAL_ENTRY entry = (ENUM_DEAL_ENTRY)HistoryDealGetInteger(trans.deal, DEAL_ENTRY);
   if(entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_OUT_BY)
      return;   // this is an opening deal, not a closing one — nothing to journal yet

   ulong positionTicket = (ulong)HistoryDealGetInteger(trans.deal, DEAL_POSITION_ID);

   //--- only journal once the POSITION is fully flat — a partial close
   //    (TP1/TP2/TP3) also generates a DEAL_ENTRY_OUT deal, but the
   //    position itself still exists with remaining volume until the
   //    final piece (TP3/TP4/SL/manual) closes it entirely
   if(PositionSelectByTicket(positionTicket))
      return;   // still open (this was a partial close) — not the final exit yet

   PendingTradeMeta meta;
   if(!TakePendingMeta(positionTicket, meta))
     {
      //--- no stored metadata — either this position was opened before
      //    this EA instance started (e.g. terminal restart) or by manual/
      //    other-EA action sharing the same magic number by coincidence.
      //    Journal it anyway with placeholder metadata rather than losing
      //    the record entirely, but flag it clearly. Entry price can still
      //    be recovered from this position's own opening deal in history —
      //    HistorySelectByPosition + scanning for DEAL_ENTRY_IN — rather
      //    than left at 0, which would silently zero out its R-multiple.
      meta.score = 0.0;
      meta.grade = "UNKNOWN";
      meta.regime = "UNKNOWN";
      meta.setupType = "UNTRACKED_POSITION";
      meta.entryTime = (datetime)HistoryDealGetInteger(trans.deal, DEAL_TIME);
      meta.entryPrice = 0.0;
      meta.structureScore = 0.0;
      meta.obScore = 0.0;
      meta.fvgScore = 0.0;
      meta.liquidityScore = 0.0;
      meta.displacementScore = 0.0;
      meta.volumeScore = 0.0;
      meta.momentumScore = 0.0;
      meta.atrRatio = 0.0;
      meta.adx = 0.0;
      if(HistorySelectByPosition(positionTicket))
        {
         int dealTotal = HistoryDealsTotal();
         for(int i = 0; i < dealTotal; i++)
           {
            ulong dealTicket = HistoryDealGetTicket(i);
            if(dealTicket == 0) continue;
            if((ENUM_DEAL_ENTRY)HistoryDealGetInteger(dealTicket, DEAL_ENTRY) == DEAL_ENTRY_IN)
              {
               meta.entryPrice = HistoryDealGetDouble(dealTicket, DEAL_PRICE);
               meta.entryTime  = (datetime)HistoryDealGetInteger(dealTicket, DEAL_TIME);
               break;
              }
           }
        }
      Print("OnTradeTransaction — closed position ", positionTicket, " had no stored metadata (terminal restart or external open?). Journaling with placeholders; entry price recovered from deal history where possible.");
     }

   double exitPrice = HistoryDealGetDouble(trans.deal, DEAL_PRICE);
   datetime exitTime = (datetime)HistoryDealGetInteger(trans.deal, DEAL_TIME);
   string symbol = HistoryDealGetString(trans.deal, DEAL_SYMBOL);
   ENUM_DEAL_TYPE dealType = (ENUM_DEAL_TYPE)HistoryDealGetInteger(trans.deal, DEAL_TYPE);
   bool wasLongPosition = (dealType == DEAL_TYPE_SELL);   // a SELL deal closes a LONG position

   //--- SL at close time (post break-even/trailing) — intentional: an
   //    accurate R-multiple should be measured against the stop that was
   //    actually in force when the position closed, not the original one
   double slAtClose = HistoryDealGetDouble(trans.deal, DEAL_SL);
   //--- AUDIT FIX: entry price now comes from the metadata captured at
   //    OPEN time (StorePendingMeta), not from PositionGetDouble() called
   //    here — the position no longer exists at this point (already
   //    confirmed above via PositionSelectByTicket returning false), so
   //    that call was returning 0/stale data and silently corrupting
   //    every R-multiple calculation. This was flagged in a comment in
   //    the original draft but the fix was never actually applied —
   //    caught on review before shipping.
   double entryPriceForR = meta.entryPrice;

   g_journal.RecordTrade(positionTicket, symbol, wasLongPosition, meta.entryTime, exitTime,
                          entryPriceForR, slAtClose, exitPrice, meta.score, meta.grade, meta.regime, meta.setupType,
                          meta.structureScore, meta.obScore, meta.fvgScore, meta.liquidityScore,
                          meta.displacementScore, meta.volumeScore, meta.momentumScore, meta.atrRatio, meta.adx);

   double riskDist = MathAbs(entryPriceForR - slAtClose);
   double rMultiple = (riskDist > 0) ? ((wasLongPosition ? (exitPrice - entryPriceForR) : (entryPriceForR - exitPrice)) / riskDist) : 0.0;
   g_risk.RecordTradeResult(rMultiple > 0);

   //--- Phase 3.13: post-trade attribution (research only)
   if(InpEnableTradeAttribution)
     {
      double dealProfit = HistoryDealGetDouble(trans.deal, DEAL_PROFIT)
                          + HistoryDealGetDouble(trans.deal, DEAL_SWAP)
                          + HistoryDealGetDouble(trans.deal, DEAL_COMMISSION);
      g_tradeAttr.ProcessClose(positionTicket, exitPrice, exitTime, dealProfit);
      if(InpLogTradeAttribution)
         g_tradeAttr.LogReport(g_tradeAttr.Last());
     }
  }

//+------------------------------------------------------------------+
double OnTester()
  {
   return g_optimizer.ComputeCriterion(g_journal);
  }
//+------------------------------------------------------------------+
